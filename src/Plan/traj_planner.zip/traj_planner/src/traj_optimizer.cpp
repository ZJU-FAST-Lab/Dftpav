#include "plan_manage/traj_optimizer.h"
// using namespace std;

namespace plan_manage
{
  /* main planning API */
  bool PolyTrajOptimizer::OptimizeTrajectory(
      const Eigen::MatrixXd &iniState, const Eigen::MatrixXd &finState,
      Eigen::MatrixXd &initInnerPts, const Eigen::VectorXd &initT,
      std::vector<Eigen::MatrixXd> &hPolys, common::State &head_state, int singul, double help_eps)
  {
    if (initInnerPts.cols() != (initT.size() - 1))
    {
      ROS_ERROR("initInnerPts.cols() != (initT.size()-1)");
      return false;
    }
    // debug_P.clear();
    // debug_T.clear();
    // debug_cost.clear();
    piece_num_ = initT.size();
    head_state_ = head_state;
    singul_ = singul;

    cfgHs = hPolys;
    epis = help_eps;
    for (int i = 0; i < piece_num_; i++)
    {
      cfgHs[i].topRows<2>().colwise().normalize(); // norm vector outside
    }

    ctrl_points_.resize(2, piece_num_ * traj_resolution_ + 1); //traj_resolution = 5
    jerkOpt_.reset(iniState, finState, piece_num_);

    double final_cost;
    variable_num_ = 3 * (piece_num_ - 1) + 1;

    ros::Time t0 = ros::Time::now(), t1, t2;
    int restart_nums = 0, rebound_times = 0;
    bool flag_force_return, flag_still_occ, flag_success;

    double q[variable_num_];
    //initInnerPts.block(0, 1, 2, PN - 1) q: Intervals+T = 2*(piecenum-1)+piecenum = 3*(piecenum-1)+1
    memcpy(q, initInnerPts.data(), initInnerPts.size() * sizeof(q[0]));
    Eigen::Map<Eigen::VectorXd> Vt(q + initInnerPts.size(), initT.size());
    RealT2VirtualT(initT, Vt);

    lbfgs::lbfgs_parameter_t lbfgs_params;
    lbfgs::lbfgs_load_default_parameters(&lbfgs_params);
    // lbfgs_params.mem_size = 16;
    // lbfgs_params.max_iterations = 200;
    // lbfgs_params.g_epsilon = 0.1;
    // lbfgs_params.min_step = 1e-32;

    // lbfgs_params.max_iterations = 200;
    // lbfgs_params.g_epsilon = 0.1;
    // lbfgs_params.min_step = 1e-32;
    // lbfgs_params.line_search_type = 0;

    lbfgs_params.max_iterations = 200;
    lbfgs_params.mem_size = 128;
    lbfgs_params.past = 3;
    lbfgs_params.g_epsilon = 1.0e-16;
    lbfgs_params.min_step = 1.0e-32;
    lbfgs_params.delta = 1.0e-6;
    lbfgs_params.line_search_type = 0;
    t_now_ = ros::Time::now().toSec();

    do
    {
      /* ---------- prepare ---------- */
      iter_num_ = 0;
      flag_force_return = false;
      force_stop_type_ = DONT_STOP;
      flag_still_occ = false;
      flag_success = false;

      /* ---------- optimize ---------- */
      t1 = ros::Time::now();
      int result = lbfgs::lbfgs_optimize(
          variable_num_,
          q,
          &final_cost,
          PolyTrajOptimizer::costFunctionCallback,
          NULL,
          NULL,
          this,
          &lbfgs_params);

      t2 = ros::Time::now();
      double time_ms = (t2 - t1).toSec() * 1000;
      double total_time_ms = (t2 - t0).toSec() * 1000;
      /* ---------- get result and check collision ---------- */
      if (result == lbfgs::LBFGS_CONVERGENCE ||
          result == lbfgs::LBFGSERR_MAXIMUMITERATION ||
          result == lbfgs::LBFGS_ALREADY_MINIMIZED ||
          result == lbfgs::LBFGS_STOP)
      {
        flag_force_return = false;
        flag_success = true;
        printf("\033[32miter=%d,time(ms)=%5.3f,total_t(ms)=%5.3f,cost=%5.3f\n\033[0m", iter_num_, time_ms, total_time_ms, final_cost);

      }
      else if (result == lbfgs::LBFGSERR_MAXIMUMLINESEARCH){
        printf("\033[32miter=%d,time(ms)=%5.3f,total_t(ms)=%5.3f,cost=%5.3f\n\033[0m", iter_num_, time_ms, total_time_ms, final_cost);
        ROS_ERROR("Lbfgs: The line-search routine reaches the maximum number of evaluations.");
        flag_force_return = false;
        flag_success = true;
      }
      else if (result == lbfgs::LBFGSERR_CANCELED)
      {
        flag_force_return = true;
        rebound_times++;
        printf("\033[33m[PolyTrajOptimizer]iter=%d,time(ms)=%5.3f, rebound.\n\033[0m", iter_num_, time_ms);
      }
      else
      {
        printf("\033[31m[PolyTrajOptimizer]iter=%d,time(ms)=%5.3f, error.\n\033[0m", iter_num_, time_ms);
        ROS_WARN("Solver error. Return = %d, %s. Skip this planning.", result, lbfgs::lbfgs_strerror(result));
      }

    } while (
        (flag_still_occ && restart_nums < 3) ||
        (flag_force_return && force_stop_type_ == STOP_FOR_REBOUND && rebound_times <= 20));

    initInnerPts  = ctrl_points_;
    // ros::shutdown();

    return flag_success;
  }

  /* callbacks by the L-BFGS optimizer */
  double PolyTrajOptimizer::costFunctionCallback(void *func_data, const double *x, double *grad, const int n)
  {
    PolyTrajOptimizer *opt = reinterpret_cast<PolyTrajOptimizer *>(func_data);

    //opt->min_ellip_dist2_ = std::numeric_limits<double>::max();

    Eigen::Map<const Eigen::MatrixXd> P(x, 2, opt->piece_num_ - 1);
    Eigen::Map<const Eigen::VectorXd> t(x + (2 * (opt->piece_num_ - 1)), opt->piece_num_);
    Eigen::Map<Eigen::MatrixXd> gradP(grad, 2, opt->piece_num_ - 1);
    Eigen::Map<Eigen::VectorXd> gradt(grad + (2 * (opt->piece_num_ - 1)), opt->piece_num_);
    Eigen::VectorXd T(opt->piece_num_);

    opt->VirtualT2RealT(t, T);

    Eigen::VectorXd gradT(opt->piece_num_);
    double smoo_cost = 0, time_cost = 0;
    Eigen::VectorXd obs_surround_feas_qvar_costs(4);
    obs_surround_feas_qvar_costs.setZero();
    gradT.setZero();
    gradP.setZero();

    opt->jerkOpt_.generate(P, T); // update b

    opt->initAndGetSmoothnessGradCost2PT(gradT, smoo_cost); // Smoothness cost   // youwenti 

    opt->addPVAGradCost2CT(gradT, obs_surround_feas_qvar_costs, opt->traj_resolution_); // Time int cost

    opt->jerkOpt_.getGrad2TP(gradT, gradP); // gradC->gradT gradC->gradP

    opt->VirtualTGradCost(T, t, gradT, gradt, time_cost);

    opt->iter_num_ += 1;
    
    // std::cout<<"iter num: "<<opt->iter_num_<<" total cost: "<<smoo_cost + obs_surround_feas_qvar_costs.sum() + time_cost
    // <<"  smoocost: "<<smoo_cost<<" feascost: "<<obs_surround_feas_qvar_costs.sum()<<" timecost: "<<time_cost<<"\n";

    // std::cout<<"waypoints: \n"<<P<<"\n";
    // std::cout<<"intervals: "<<T.transpose()<<"\n";
    // std::cout<<"grad P: \n"<<gradP<<"\n";
    // std::cout<<"grad t: \n"<<gradt.transpose()<<"\n";
    // if(opt->iter_num_ ==1){
    //   std::cout<<"first cost: "<<smoo_cost + obs_surround_feas_qvar_costs.sum() + time_cost<<std::endl;
    // }
    // std::cout<<"smoo cost: "<<smoo_cost<<"qvar: "<<obs_surround_feas_qvar_costs.sum()<<" timecost: "<<time_cost<<std::endl;
    // std::cout<<"total cost: "<<smoo_cost + obs_surround_feas_qvar_costs.sum() + time_cost<<std::endl;
    return smoo_cost + obs_surround_feas_qvar_costs.sum() + time_cost;
  }

  int PolyTrajOptimizer::earlyExitCallback(void *func_data, const double *x, const double *g, const double fx, const double xnorm, const double gnorm, const double step, int n, int k, int ls)
  {
    PolyTrajOptimizer *opt = reinterpret_cast<PolyTrajOptimizer *>(func_data);

    return (opt->force_stop_type_ == STOP_FOR_ERROR || opt->force_stop_type_ == STOP_FOR_REBOUND);
  }

  /* mappings between real world time and unconstrained virtual time */
  template <typename EIGENVEC>
  void PolyTrajOptimizer::RealT2VirtualT(const Eigen::VectorXd &RT, EIGENVEC &VT)
  {
    for (int i = 0; i < RT.size(); ++i)
    {
      VT(i) = RT(i) > 1.0 ? (sqrt(2.0 * RT(i) - 1.0) - 1.0)
                          : (1.0 - sqrt(2.0 / RT(i) - 1.0));
    }
  }

  template <typename EIGENVEC>
  void PolyTrajOptimizer::VirtualT2RealT(const EIGENVEC &VT, Eigen::VectorXd &RT)
  {
    for (int i = 0; i < VT.size(); ++i)
    {
      RT(i) = VT(i) > 0.0 ? ((0.5 * VT(i) + 1.0) * VT(i) + 1.0)
                          : 1.0 / ((0.5 * VT(i) - 1.0) * VT(i) + 1.0);
    }
  }

  template <typename EIGENVEC, typename EIGENVECGD>
  void PolyTrajOptimizer::VirtualTGradCost(
      const Eigen::VectorXd &RT, const EIGENVEC &VT,
      const Eigen::VectorXd &gdRT, EIGENVECGD &gdVT,
      double &costT)
  {
    for (int i = 0; i < VT.size(); ++i)
    {
      double gdVT2Rt;
      if (VT(i) > 0)
      {
        gdVT2Rt = VT(i) + 1.0;
      }
      else
      {
        double denSqrt = (0.5 * VT(i) - 1.0) * VT(i) + 1.0;
        gdVT2Rt = (1.0 - VT(i)) / (denSqrt * denSqrt);
      }

      gdVT(i) = (gdRT(i) + wei_time_) * gdVT2Rt;
    }

    costT = RT.sum() * wei_time_;
  }

  /* gradient and cost evaluation functions */
  template <typename EIGENVEC>
  void PolyTrajOptimizer::initAndGetSmoothnessGradCost2PT(EIGENVEC &gdT, double &cost)
  {
    jerkOpt_.initGradCost(gdT, cost);
  }

  template <typename EIGENVEC>
  void PolyTrajOptimizer::addPVAGradCost2CT(EIGENVEC &gdT, Eigen::VectorXd &costs, const int &K)
  {
    
    // output gradT gradC 
    int N = gdT.size();
    Eigen::Vector2d outerNormal;
    Eigen::Vector2d sigma, dsigma, ddsigma, dddsigma;
    double vel2_reci,vel2_reci_e,acc2, cur2;
    Eigen::Matrix<double, 6, 1> beta0, beta1, beta2, beta3;
    double s1, s2, s3, s4, s5;
    double step, alpha;
    Eigen::Matrix<double, 6, 2> gradViolaPc, gradViolaVc, gradViolaAc, gradViolaKc;
    double gradViolaPt, gradViolaVt, gradViolaAt, gradViolaKt;
    double violaPos, violaVel, violaAcc, violaCur;
    double violaPosPenaD, violaVelPenaD, violaAccPenaD, violaCurPenaD;
    double violaPosPena, violaVelPena, violaAccPena, violaCurPena;

    double omg;
    int i_dp = 0; // the index of constrain points
    costs.setZero();
    double z_h0, z_h1, z_h2, z_h3, z_h4, z_h5;
    double z_h5_e;
    Eigen::Matrix2d ego_R, help_R;
    /*debug*/
    cos_points.clear();
    debug_hPolys.clear();
    key_points.clear();
    std::vector<int> cosindex;
    // int innerLoop;
    double t = 0;
    for (int i = 0; i < N; ++i)
    {
      const Eigen::Matrix<double, 6, 2> &c = jerkOpt_.get_b().block<6, 2>(i * 6, 0);
      step = jerkOpt_.get_T1()(i) / K; // T_i /k
      s1 = 0.0;
      // innerLoop = K;
      for (int j = 0; j <= K; ++j)
      {
        s2 = s1 * s1;
        s3 = s2 * s1;
        s4 = s2 * s2;
        s5 = s4 * s1;
        beta0 << 1.0, s1, s2, s3, s4, s5;
        beta1 << 0.0, 1.0, 2.0 * s1, 3.0 * s2, 4.0 * s3, 5.0 * s4;
        beta2 << 0.0, 0.0, 2.0, 6.0 * s1, 12.0 * s2, 20.0 * s3;
        beta3 << 0.0, 0.0, 0.0, 6.0, 24.0 * s1, 60.0 * s2;
        alpha = 1.0 / K * j;

        sigma = c.transpose() * beta0;
        dsigma = c.transpose() * beta1;
        ddsigma = c.transpose() * beta2;
        dddsigma = c.transpose() * beta3;

         
        ctrl_points_.col(i_dp) = sigma;
        omg = (j == 0 || j == K) ? 0.5 : 1.0;

        // some help values
        
        z_h0 = dsigma.norm();
        z_h1 = ddsigma.transpose() * dsigma;
        z_h2 = dddsigma.transpose() * dsigma;
        z_h3 = ddsigma.transpose() * B_h * dsigma;
      

        // update
        s1 += step;
        if (j != K || (j == K && i == N - 1))
        {
          ++i_dp;
        }


        // add cost z_h0 = ||v||
        if ( z_h0 < 1e-4)
        {
          continue;
        }
        //avoid siguality

        vel2_reci = 1.0 / (z_h0 * z_h0);
        vel2_reci_e = 1.0 / (z_h0 * z_h0+epis);

        z_h0 = 1.0 / z_h0;

        z_h4 = z_h1 * vel2_reci;
        z_h5 = z_h3 * (vel2_reci * vel2_reci * vel2_reci);
        z_h5_e = z_h3 * (vel2_reci_e * vel2_reci_e * vel2_reci_e);
        violaVel = 1.0 / vel2_reci - max_vel_ * max_vel_;
        acc2 = z_h1 * z_h1 * vel2_reci;
        cur2 = z_h3 * z_h3 * (vel2_reci_e * vel2_reci_e * vel2_reci_e);
        //@yuwei: add feasibility with curvature
        violaAcc = acc2 - max_acc_ * max_acc_;
        violaCur = cur2 - max_cur_ * max_cur_;

        ego_R << dsigma(0), -dsigma(1),
                 dsigma(1),  dsigma(0);
        ego_R = ego_R * z_h0;

        help_R << ddsigma(0), -ddsigma(1),
                  ddsigma(1),  ddsigma(0);
        help_R = help_R * z_h0;

        //collision-free 
        //for corridor constraints with bound points
        for (auto lz : lz_set_)
        {

          lz(0) += singul_ * veh_param_.d_cr(); 

          Eigen::Vector2d bpt = sigma + ego_R * lz;
          Eigen::Matrix2d help_L;
          help_L << lz(0), -lz(1),
                    lz(1),  lz(0);

            
          int corr_k = cfgHs[i].cols();

          /*for (int k = 0; k < corr_k; k++)
          {
            outerNormal = cfgHs[i].col(k).head<2>();
            violaPos = outerNormal.dot(bpt - cfgHs[i].col(k).tail<2>());
            if (violaPos > 0.0)
            {
              if(cosindex.size()==0){
                cosindex.push_back(i);
                cos_points.push_back(bpt);
              }
              else{
                if(i==cosindex.back()){
                  cos_points.push_back(bpt);
                }
              }
              positiveSmoothedL1(violaPos, violaPosPena, violaPosPenaD);

              gradViolaPc = beta0 * outerNormal.transpose() +
                            beta1 * outerNormal.transpose() * (help_L * z_h0 - ego_R * lz * dsigma.transpose() * vel2_reci);

              gradViolaPt = alpha * outerNormal.transpose() * (dsigma + help_R * lz - ego_R * z_h1 * lz * vel2_reci);

              jerkOpt_.get_gdC().block<6, 2>(i * 6, 0) += omg * step * wei_obs_ * violaPosPenaD * gradViolaPc;
              gdT(i) += omg * wei_obs_ * (violaPosPenaD * gradViolaPt * step + violaPosPena / K);

              costs(0) += omg * step * wei_obs_ * violaPosPena; // cost is the same
            }
          }*/

        }

        
        // ---------------------surrounding vehicle avoidance
        double gradt, grad_prev_t, costp;
        Eigen::Vector2d gradp, gradp2;


        // if(surroundGradCostP(i_dp, t + step * j, sigma, dsigma, gradp, gradt, grad_prev_t, costp))
        // {

        //signed dist 
        
        if (dynamicObsGradCostP(i_dp, t + step * j, sigma, dsigma, ddsigma, ego_R, help_R,
                                gradp, gradp2, gradt, grad_prev_t, costp))
        {

          gradViolaPc = beta0 * gradp.transpose() + beta1 * gradp2.transpose();
          gradViolaPt = alpha * gradt;
          jerkOpt_.get_gdC().block<6, 2>(i * 6, 0) += omg * step * wei_surround_ * gradViolaPc; // j gradient to c
          gdT(i) += omg * wei_surround_ * (costp / K + step * gradViolaPt);                     // j gradient to t
          if (i > 0)
          {
            gdT.head(i).array() += omg * step * wei_surround_ * grad_prev_t; // the gradient of virtual t
          }
          costs(1) += omg * step * wei_surround_ * costp; // the J
        }
        

        //@yuwei revised feasibility
        if (violaVel > 0.0)
        {
          positiveSmoothedL1(violaVel, violaVelPena, violaVelPenaD);

          gradViolaVc = 2.0 * beta1 * dsigma.transpose(); // 6*2
          gradViolaVt = 2.0 * alpha * z_h1;               // 1*1
          jerkOpt_.get_gdC().block<6, 2>(i * 6, 0) += omg * step * wei_feas_ * violaVelPenaD * gradViolaVc;
          gdT(i) += omg * wei_feas_ * (violaVelPenaD * gradViolaVt * step + violaVelPena / K);
          costs(2) += omg * step * wei_feas_ * violaVelPena;
        }
        
        
        if (violaAcc > 0.0)
        {
          positiveSmoothedL1(violaAcc, violaAccPena, violaAccPenaD);
          //@yuwei
          gradViolaAc = 2.0 * beta1 * (z_h4 * ddsigma.transpose() - z_h4 * z_h4 * dsigma.transpose()) +
                        2.0 * beta2 * z_h4 * dsigma.transpose(); // 6*2
          gradViolaAt = 2.0 * alpha * (z_h4 * (ddsigma.squaredNorm() + z_h2) - z_h4 * z_h4 * z_h1);
          jerkOpt_.get_gdC().block<6, 2>(i * 6, 0) += omg * step * wei_feas_ * violaAccPenaD * gradViolaAc;
          gdT(i) += omg * wei_feas_ * (violaAccPenaD * gradViolaAt * step + violaAccPena / K);
          costs(2) += omg * step * wei_feas_ * violaAccPena;
        } 
        
        if (violaCur > 0.0)
        {
          positiveSmoothedL1(violaCur, violaCurPena, violaCurPenaD);
          //@yuwei hzc
          gradViolaKc = 2.0 * beta1 * (z_h5_e * ddsigma.transpose()*B_h - 3 * z_h5_e * z_h3 * vel2_reci_e * dsigma.transpose()) +
                        2.0 * beta2 * z_h5_e * dsigma.transpose() * B_h.transpose(); // 6*2
          gradViolaKt  = 2.0*alpha*z_h5_e*(dddsigma.transpose()*B_h*dsigma-3*vel2_reci_e*z_h3*z_h1);
          jerkOpt_.get_gdC().block<6, 2>(i * 6, 0) += omg * step * wei_feas_ * 100.0 * violaCurPenaD * gradViolaKc;
          gdT(i) += omg * wei_feas_ * 100.0 * (violaCurPenaD * gradViolaKt * step + violaCurPena / K);
          costs(2) += omg * step * wei_feas_ * 100.0 * violaCurPena;


        }
      }
      t += jerkOpt_.get_T1()(i);
    }

    /*for(int idx:cosindex){
      debug_hPolys.push_back(cfgHs[idx]);  
      debug_hPolys.push_back(cfgHs[idx+1]);  
      debug_hPolys.push_back(cfgHs[idx+2]);  
      key_points.push_back(jerkOpt_.getTraj(1)[idx].getPos(0));
      key_points.push_back(jerkOpt_.getTraj(1)[idx].getPos(jerkOpt_.getTraj(1)[idx].getDuration()));
      key_points.push_back(jerkOpt_.getTraj(1)[idx+1].getPos(0));
      key_points.push_back(jerkOpt_.getTraj(1)[idx+1].getPos(jerkOpt_.getTraj(1)[idx].getDuration()));
      key_points.push_back(jerkOpt_.getTraj(1)[idx+2].getPos(0));
      key_points.push_back(jerkOpt_.getTraj(1)[idx+2].getPos(jerkOpt_.getTraj(1)[idx].getDuration()));
    }
    
    displayPoints();
    displayCosPoints();
    displayBugPoly();
    displayKeyPoints();
    ros::Duration(0.1).sleep();*/
    // for(int i = 14;i<=18;i++){
    //   debug_hPolys.push_back(cfgHs[i]);  
    //   key_points.push_back(jerkOpt_.getTraj(singul_)[i].getPos(0));
    //   key_points.push_back(jerkOpt_.getTraj(singul_)[i].getPos(jerkOpt_.getTraj(singul_)[i].getDuration()));
    // }
    // displayBugPoly();
    // displayKeyPoints();
    // std::cout<<"corridor cost: "<<costs(0)<<"\n";
    // std::cout<<"dynamic cost: "<<costs(2)<<"\n";

  }


  ///viola*, viola*Pena, viola*PenaD
  void PolyTrajOptimizer::positiveSmoothedL1(const double &x, double &f, double &df)
  {
        const double pe = 1.0e-4;
        const double half = 0.5 * pe;
        const double f3c = 1.0 / (pe * pe);
        const double f4c = -0.5 * f3c / pe;
        const double d2c = 3.0 * f3c;
        const double d3c = 4.0 * f4c;

        if (x < pe)
        {
            f = (f4c * x + f3c) * x * x * x;
            df = (d3c * x + d2c) * x * x;
        }
        else
        {
            f = x - half;
            df = 1.0;
        }

        return;
  }


  void PolyTrajOptimizer::getBoundPts(Eigen::Vector2d &position, double angle,
                                      std::vector<Eigen::Vector2d> &BoundVertices)
  {

    BoundVertices.clear();

    double cos_theta = cos(angle);
    double sin_theta = sin(angle);

    double c_x = position(0) + veh_param_.d_cr() * cos_theta; // the vehicle model is based on the rear wheel
    double c_y = position(1) + veh_param_.d_cr() * sin_theta;
    double d_wx = veh_param_.width() / 2 * sin_theta;
    double d_wy = veh_param_.width() / 2 * cos_theta;
    double d_lx = veh_param_.length() / 2 * cos_theta;
    double d_ly = veh_param_.length() / 2 * sin_theta;
    // Counterclockwise from left-front vertex
    BoundVertices.push_back(Eigen::Vector2d(c_x - d_wx + d_lx, c_y + d_wy + d_ly));
    BoundVertices.push_back(Eigen::Vector2d(c_x - d_wx - d_lx, c_y - d_ly + d_wy));
    BoundVertices.push_back(Eigen::Vector2d(c_x + d_wx - d_lx, c_y - d_wy - d_ly));
    BoundVertices.push_back(Eigen::Vector2d(c_x + d_wx + d_lx, c_y + d_ly - d_wy));
  }

  // using the circle model, for other cars(with same parameters)
  bool PolyTrajOptimizer::surroundGradCostP(const int i_dp,           // index of constraint point
                                            const double t,           // current absolute time
                                            const Eigen::Vector2d &p, // the rear model
                                            const Eigen::Vector2d &v,
                                            Eigen::Vector2d &gradp,
                                            double &gradt,
                                            double &grad_prev_t,
                                            double &costp)
  {
    if (i_dp <= 0) return false;
    if (surround_trajs_->size() < 1) return false;

    bool ret = false;

    gradp.setZero();
    gradt = 0;
    grad_prev_t = 0;
    costp = 0;

    const double CLEARANCE2 = (surround_clearance_ * 1.5) * (surround_clearance_ * 1.5);
    // only counts when the distance is smaller than clearance

    constexpr double b = 1.0, inv_b2 = 1 / b / b;

    double pt_time = t_now_ + t;

    if (surround_trajs_->size() < 1) return false;

    for (size_t id = 0; id < surround_trajs_->size(); id++)
    {

      double traj_i_satrt_time = surround_trajs_->at(id).start_time;

      Eigen::Vector2d surround_p, surround_v;
      if (pt_time < traj_i_satrt_time + surround_trajs_->at(id).duration)
      {
        surround_p = surround_trajs_->at(id).traj.getPos(pt_time - traj_i_satrt_time);
        surround_v = surround_trajs_->at(id).traj.getdSigma(pt_time - traj_i_satrt_time);
      }
      else
      {
        double exceed_time = pt_time - (traj_i_satrt_time + surround_trajs_->at(id).duration);
        surround_v = surround_trajs_->at(id).traj.getdSigma(surround_trajs_->at(id).duration);
        surround_p = surround_trajs_->at(id).traj.getPos(surround_trajs_->at(id).duration) +
                     exceed_time * surround_v;
      }

      Eigen::Vector2d dist_vec = p - surround_p;
      double ellip_dist2 = (dist_vec(0) * dist_vec(0) + dist_vec(1) * dist_vec(1)) * inv_b2;
      double dist2_err = CLEARANCE2 - ellip_dist2;
      double dist2_err2 = dist2_err * dist2_err;
      double dist2_err3 = dist2_err2 * dist2_err;

      if (dist2_err3 > 0) // only accout the cost term when the distance is within the clearance
      {
        ret = true;

        costp += wei_surround_ * dist2_err3;
        Eigen::Vector2d dJ_dP = wei_surround_ * 3 * dist2_err2 * (-2) * Eigen::Vector2d(inv_b2 * dist_vec(0), inv_b2 * dist_vec(1));
        gradp += dJ_dP;
        gradt += dJ_dP.dot(v - surround_v);
        grad_prev_t += dJ_dP.dot(-surround_v);
      }

      if (min_ellip_dist2_ > ellip_dist2)
      {
        min_ellip_dist2_ = ellip_dist2;
      }
    }

    return ret;
  }

  // develop with signed distance
  // for current simulation, they add only vehicles with the same size.
  // in the future, more size can be added
  bool PolyTrajOptimizer::dynamicObsGradCostP(const int i_dp,               // index of constraint point
                                              const double t,               // current absolute time
                                              const Eigen::Vector2d &sigma, // the rear model
                                              const Eigen::Vector2d &dsigma,
                                              const Eigen::Vector2d &ddsigma,
                                              Eigen::Matrix2d &ego_R,
                                              Eigen::Matrix2d &help_R,
                                              Eigen::Vector2d &gradp,
                                              Eigen::Vector2d &gradp2,
                                              double &gradt,
                                              double &grad_prev_t,
                                              double &costp)
  {

    if (i_dp <= 0) return false;
    if (surround_trajs_==NULL||surround_trajs_->size() < 1) return false;

    //t means the cur-t of the constraint point
    bool ret = false;

    gradp.setZero();
    gradp2.setZero();
    gradt = 0;
    grad_prev_t = 0;
    costp = 0;

    double alpha = 1.0, d_min = surround_clearance_ - std::log(8.0) / alpha;

    // only counts when the distance is smaller than clearance
    double dG_dsd, temp0, temp0_reci, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
    double temp_sur0, temp_sur_reci0, temp_sur1, temp_sur2, temp_sur3;
    Eigen::Vector2d temp_vec1, temp_vec2, temp_vec3, temp_vec4;
    Eigen::Matrix<double, 2, 4> grad_sd_sigma, grad_sd_dsigma, ego_bound_points, surround_bound_points;
    Eigen::VectorXd grad_sd_rt(4), grad_sd_prevt(4);

    temp0 = dsigma.norm(); //  ||dsigma||_2
    
    if (temp0 != 0.0){
      temp0_reci = 1.0 / temp0;
    }else{
      temp0_reci = 0.0;
    }

    temp1 = double(dsigma.transpose() * sigma) * temp0_reci; //(dsigma.transpose() * sigma) / temp0_reci; // dsigma^T * sigma /  ||dsigma||_2
    temp2 = double(dsigma.transpose() * B_h * sigma) * temp0_reci;
    temp3 = temp0_reci * temp0_reci; // ||dsigma||_2^2
    temp4 = temp3 * temp0_reci; // ||dsigma||_2^3
    temp5 = double(ddsigma.transpose() * dsigma) * temp3;
    temp6 = -(temp0 + double(ddsigma.transpose() * sigma) * temp0_reci + temp5 * temp1);
    temp7 = -(double(ddsigma.transpose() * B_h * sigma) * temp0_reci + temp5 * temp2);

    temp_vec1 = -(sigma * temp0_reci + temp1 * temp3 * dsigma);
    temp_vec2 = -(B_h * sigma * temp0_reci + temp2 * temp3 * dsigma);

    grad_sd_sigma.col(0) = -dsigma * temp0_reci;
    grad_sd_sigma.col(1) = -B_h.transpose() * dsigma * temp0_reci;

    double pt_time = t_now_ + t;

    for (size_t id = 0; id < surround_trajs_->size(); id++)
    {

      double traj_i_satrt_time = surround_trajs_->at(id).start_time;

      Eigen::Vector2d surround_p, surround_v, surround_a;
      if (pt_time < traj_i_satrt_time + surround_trajs_->at(id).duration)
      {
        surround_p = surround_trajs_->at(id).traj.getPos(pt_time - traj_i_satrt_time);
        surround_v = surround_trajs_->at(id).traj.getdSigma(pt_time - traj_i_satrt_time);
        surround_a = surround_trajs_->at(id).traj.getddSigma(pt_time - traj_i_satrt_time);
      }
      else
      {
        double exceed_time = pt_time - (traj_i_satrt_time + surround_trajs_->at(id).duration);
        surround_v = surround_trajs_->at(id).traj.getdSigma(surround_trajs_->at(id).duration);
        surround_p = surround_trajs_->at(id).traj.getPos(surround_trajs_->at(id).duration) +
                     exceed_time * surround_v;
        surround_a = surround_trajs_->at(id).traj.getddSigma(surround_trajs_->at(id).duration);
      }

      Eigen::Vector2d dist_vec = sigma - surround_p;
      double dist_err = dist_vec.norm();
      double dist_err_diff = surround_clearance_ - dist_err;

      if (dist_err_diff > 0) // only acount the cost term when the distance is within the safety clearance
      {
        temp_sur0 = surround_v.norm();
        if (temp_sur0 != 0.0)
        {
          temp_sur_reci0 = 1.0 / temp_sur0;
        }
        else
        {
          temp_sur_reci0 = 0.0;
        }

        temp_sur1 = double(surround_v.transpose() * surround_p) * temp_sur_reci0;
        temp_sur2 = double(surround_v.transpose() * B_h * surround_p) * temp_sur_reci0;
        temp_sur3 = double(surround_a.transpose() * surround_v) * (temp_sur_reci0 * temp_sur_reci0);

        Eigen::Matrix2d surround_R;
        surround_R << surround_v(0), -surround_v(1),
            surround_v(1), surround_v(0);
        surround_R = surround_R * temp_sur_reci0;

        //  ==========the help intermediate variables.
        Eigen::VectorXd signed_dists(8),
            ego_signed_dists1(4), ego_signed_dists2(4),
            surround_signed_dists1(4), surround_signed_dists2(4);
        Eigen::Vector2d temp_point;
        Eigen::Matrix2d temp_matrix1, temp_matrix2;
        double surround_exp_sum1, surround_exp_sum2, ego_exp_sum1, ego_exp_sum2, exp_sum;
        // ===========the help intermediate variables.

        for (unsigned int i = 0; i < 4; i++)
        {
          Eigen::Vector2d lz = lz_set_.at(i);
          lz(0) += singul_ * veh_param_.d_cr();

          temp_point = sigma + ego_R * lz;
          ego_signed_dists1(i) = double(surround_v.transpose() * temp_point) * temp_sur_reci0;
          ego_signed_dists2(i) = double(surround_v.transpose() * B_h * temp_point) * temp_sur_reci0;
          ego_bound_points.col(i) = temp_point; // 2*1

          temp_point = surround_p + surround_R * lz;
          surround_signed_dists1(i) = double(dsigma.transpose() * temp_point) * temp0_reci;
          surround_signed_dists2(i) = double(dsigma.transpose() * B_h * temp_point) * temp0_reci;
          surround_bound_points.col(i) = temp_point;
        }

        // d1_ego - d4_ego
        signed_dists(0) = log_sum_exp(-1.0, surround_signed_dists1, surround_exp_sum1) - temp1 - veh_param_.d_cr() - veh_param_.length() / 2.0;
        signed_dists(1) = -signed_dists(0) - veh_param_.length();
        signed_dists(2) = log_sum_exp(-1.0, surround_signed_dists2, surround_exp_sum2) - temp2 - veh_param_.width() / 2.0;
        signed_dists(3) = -signed_dists(2) - veh_param_.width();

        // d1_sur = d4_sur
        signed_dists(4) = log_sum_exp(-1.0, ego_signed_dists1, ego_exp_sum1) - temp_sur1 - veh_param_.d_cr() - veh_param_.length() / 2.0;
        signed_dists(5) = -signed_dists(4) - veh_param_.length();
        signed_dists(6) = log_sum_exp(-1.0, ego_signed_dists2, ego_exp_sum2) - temp_sur2 - veh_param_.width() / 2.0;
        signed_dists(7) = -signed_dists(6) - veh_param_.width();
        // ------------------------------- add cost
        double d_value = d_min -log_sum_exp(1.0, signed_dists, exp_sum);
        if (d_value > 0){
          ret = true;
        }else{
          continue;
        }
        costp += d_value;
        grad_sd_sigma.col(2) = -surround_v * temp_sur_reci0;
        grad_sd_sigma.col(3) = -B_h.transpose() * surround_v * temp_sur_reci0;  //correct

        temp_matrix1.setZero();
        temp_matrix2.setZero();
        grad_sd_prevt.setZero();

        grad_sd_dsigma.col(0) = temp_vec1;
        grad_sd_dsigma.col(1) = temp_vec2;

        grad_sd_rt(0) = temp6;
        grad_sd_rt(1) = temp7;
        
        grad_sd_prevt(2) = -(temp_sur0 + double(surround_a.transpose() * surround_p) * temp_sur_reci0 + temp_sur1 * temp_sur3);
        grad_sd_prevt(3) = -(double(surround_a.transpose() * B_h * surround_p) * temp_sur_reci0 + temp_sur2 * temp_sur3);
        
        double temp_exp;

        for (unsigned int i = 0; i < 4; i++)
        {
          temp_point = surround_bound_points.col(i);
          //////////////////////////   d^e_r (1)
          temp_exp = surround_signed_dists1(i) / surround_exp_sum1;
          // ok
          grad_sd_dsigma.col(0) += temp_exp * (temp_point * temp0_reci + double(dsigma.transpose() * temp_point) * temp4 * dsigma);

          //////////////////////////   d^e_r / dt (1)
          grad_sd_rt(0) += temp_exp * (double(ddsigma.transpose() * temp_point) * temp0_reci +
                                       double(dsigma.transpose() * temp_point) * temp5 * temp0_reci);
          grad_sd_prevt(0) += temp_exp * double(dsigma.transpose() * surround_v) * temp0_reci; // just neglect the second term

          //////////////////////////   d^e_r (2)
          temp_exp = surround_signed_dists2(i) / surround_exp_sum2;
           // ok
          grad_sd_dsigma.col(1) += temp_exp * (B_h * temp_point * temp0_reci + double(dsigma.transpose() * B_h * temp_point) * temp4 * dsigma);
          //////////////////////////   d^e_r / dt (2)
          grad_sd_rt(1) += temp_exp * (double(ddsigma.transpose() * B_h * temp_point) * temp0_reci +
                                       double(dsigma.transpose() * B_h * temp_point) * temp5 * temp0_reci);
          grad_sd_prevt(1) += temp_exp * double(dsigma.transpose() * B_h * surround_v) * temp0_reci; // just neglect the second term

          //////////////////////////
          temp_point = ego_bound_points.col(i);

          Eigen::Matrix2d help_L1;
          Eigen::Vector2d help_L2;
          Eigen::Vector2d lz = lz_set_.at(i);
          lz(0) += singul_ * veh_param_.d_cr();

          help_L1 << lz(0), -lz(1),
                     lz(1),  lz(0);
          
          help_L1 = help_L1 * temp0_reci + (ego_R * temp3) *  lz * dsigma.transpose();
          help_L2 = help_R * lz + ego_R * lz * temp5;


          //////////////////////////   d^u_r (1)
          temp_exp = ego_signed_dists1(i) / ego_exp_sum1;

          // grad_sd_dsigma(2)
          temp_matrix1     += temp_exp * help_L1;
          // grad_sd_rt(2)
          temp_vec3        += temp_exp * help_L2;
          // grad_sd_prevt(2)
          grad_sd_prevt(2) += temp_exp * (double(surround_a.transpose() * temp_point) * temp_sur_reci0 +
                                          double(surround_v.transpose() * temp_point) * temp_sur3);

          //////////////////////////   d^u_r (2)
          temp_exp = ego_signed_dists2(i) / ego_exp_sum2;
          // grad_sd_dsigma(3)
          temp_matrix2     += temp_exp * help_L1;
          // grad_sd_rt(3)
          temp_vec4        += temp_exp * help_L2;
          // grad_sd_prevt(3)
          grad_sd_prevt(3) += temp_exp * (double(surround_a.transpose() * B_h * temp_point) * temp_sur_reci0 +
                                          double(surround_v.transpose() * B_h * temp_point) * temp_sur3);
        }

        grad_sd_dsigma.col(2) = temp_matrix1.transpose() * grad_sd_sigma.col(2); // 2*2 * 2*1
        grad_sd_dsigma.col(3) = temp_matrix2.transpose() * grad_sd_sigma.col(3);

        grad_sd_rt(2) = double((grad_sd_dsigma.col(2)).transpose() * temp_vec3); //1*2 2*1
        grad_sd_rt(3) = double((grad_sd_dsigma.col(3)).transpose() * temp_vec4); //1*2 2*1

        int index;

        for (unsigned int j = 0; j < 8; j++)
        {
          dG_dsd = -(signed_dists(j) / exp_sum) * std::pow(-1, j); // 1*1
          index = j / 2;
          gradp += dG_dsd * grad_sd_sigma.col(index); // 2*1
          gradp2 += dG_dsd * grad_sd_dsigma.col(index);
          gradt += dG_dsd * grad_sd_rt(index);
          grad_prev_t += dG_dsd * grad_sd_prevt(index);
        }

      } // if the distance is within the safe distance region
    }
    //ros::shutdown();
    return ret;
  }

  double PolyTrajOptimizer::log_sum_exp(double alpha, Eigen::VectorXd &all_dists, double &exp_sum)
  {
    // all_dists will be std::exp(alpha * (all_dists(j) - d_max));
    double d_0;
    if (alpha > 0)
    {
      d_0 = all_dists.maxCoeff();
    }
    else
    {
      d_0 = all_dists.minCoeff();
    }

    exp_sum = 0;
    for (unsigned int j = 0; j < all_dists.size(); j++)
    {
      all_dists(j) = std::exp(alpha * (all_dists(j) - d_0));
      exp_sum += all_dists(j);
    }

    return std::log(exp_sum) / alpha + d_0;
  }




  /* helper functions */
  void PolyTrajOptimizer::setParam(ros::NodeHandle nh, planning::minco::Config cfg_)
  {
    traj_resolution_ = cfg_.opt_cfg().traj_resolution();
    wei_obs_ = cfg_.opt_cfg().wei_sta_obs();
    wei_surround_ = cfg_.opt_cfg().wei_dyn_obs();
    wei_feas_ = cfg_.opt_cfg().wei_feas();
    wei_sqrvar_ = cfg_.opt_cfg().wei_sqrvar();
    wei_time_ = cfg_.opt_cfg().wei_time();
    surround_clearance_ = cfg_.opt_cfg().dyn_obs_clearance();
    max_vel_ = cfg_.opt_cfg().max_vel();
    max_acc_ = cfg_.opt_cfg().max_acc();
    max_cur_ = cfg_.opt_cfg().max_cur();

    B_h << 0, -1,
           1, 0;

    debug_pub = nh.advertise<visualization_msgs::Marker>("/test_points", 2);
    debug_pub1 = nh.advertise<visualization_msgs::Marker>("/colls_points", 2);
    debug_galaxy_poly_pub_ = nh.advertise<decomp_ros_msgs::PolyhedronArray>("/debug_corridor", 1, true);
    debug_key_points_pub = nh.advertise<visualization_msgs::Marker>("/key_points", 2);

    double half_wid = 0.5 * veh_param_.width();
    double half_len = 0.5 * veh_param_.length();
    lz_set_.push_back(Eigen::Vector2d(  half_len,  half_wid));
    lz_set_.push_back(Eigen::Vector2d(- half_len,  half_wid));
    lz_set_.push_back(Eigen::Vector2d(  half_len, -half_wid));
    lz_set_.push_back(Eigen::Vector2d(- half_len, -half_wid));


  }



  void PolyTrajOptimizer::displayPoints()
  {
    visualization_msgs::Marker mk;
    mk.header.frame_id = "map";
    mk.header.stamp = ros::Time::now();
    mk.type = visualization_msgs::Marker::LINE_STRIP;
    mk.action = visualization_msgs::Marker::DELETE;

    debug_pub.publish(mk);
    geometry_msgs::Point pt;
    std_msgs::ColorRGBA pc;

    mk.action = visualization_msgs::Marker::ADD;
    mk.pose.orientation.w = 1.0;
    mk.scale.x = 0.1;

    pc.r = 0.5;
    pc.g = 0;
    pc.b = 0;
    pc.a = 0.6;

    for (int i = 0; i < ctrl_points_.cols(); i++)
    {
      
      pt.x = ctrl_points_(0, i);
      pt.y = ctrl_points_(1, i);
      if(isnan(pt.x)||isnan(pt.y)||abs(pt.x)>=100||abs(pt.y)>=100) return;
      pt.z = 0.1;

      mk.points.push_back(pt);
      mk.colors.push_back(pc);
    }

    debug_pub.publish(mk);

  }
  void PolyTrajOptimizer::displayKeyPoints()
  {
    visualization_msgs::Marker mk;
    mk.header.frame_id = "map";
    mk.header.stamp = ros::Time::now();
    mk.type = visualization_msgs::Marker::SPHERE_LIST;
    mk.action = visualization_msgs::Marker::DELETE;

    debug_key_points_pub.publish(mk);
    geometry_msgs::Point pt;
    std_msgs::ColorRGBA pc;

    mk.action = visualization_msgs::Marker::ADD;
    mk.pose.orientation.w = 1.0;
    mk.scale.x = 0.4;
    mk.scale.y = 0.4;
    mk.scale.z = 0.4;

    pc.r = 0.0;
    pc.g = 0;
    pc.b = 1.0;
    pc.a = 0.6;

    for (int i = 0; i < key_points.size(); i++)
    {
      
      pt.x = key_points[i][0];
      pt.y = key_points[i][1];
      if(isnan(pt.x)||isnan(pt.y)||abs(pt.x)>=100||abs(pt.y)>=100) return;
      pt.z = 0.3;

      mk.points.push_back(pt);
      mk.colors.push_back(pc);
    }

    debug_key_points_pub.publish(mk);

  }
  
  void PolyTrajOptimizer::displayCosPoints(){
    visualization_msgs::Marker mk;
    mk.header.frame_id = "map";
    mk.header.stamp = ros::Time::now();
    mk.type = visualization_msgs::Marker::SPHERE_LIST;
    mk.action = visualization_msgs::Marker::DELETE;

    debug_pub1.publish(mk);
    geometry_msgs::Point pt;
    std_msgs::ColorRGBA pc;

    mk.action = visualization_msgs::Marker::ADD;
    mk.pose.orientation.w = 1.0;
    mk.scale.x = 0.1;

    pc.r = 0.0;
    pc.g = 0;
    pc.b = 0;
    pc.a = 0.6;

    for (int i = 0; i < cos_points.size(); i++)
    {
      
      pt.x = cos_points[i][0];
      pt.y = cos_points[i][1];
      if(isnan(pt.x)||isnan(pt.y)||abs(pt.x)>=100||abs(pt.y)>=100) return;
      pt.z = 0.1;

      mk.points.push_back(pt);
      mk.colors.push_back(pc);
    }

    debug_pub1.publish(mk);
  }
  void  PolyTrajOptimizer::displayBugPoly(){

    vec_E<Polyhedron2D> polyhedra;
    polyhedra.reserve(debug_hPolys.size());
    for (const auto &ele : debug_hPolys)
    {
      Polyhedron2D hPoly;
      for (int i = 0; i < ele.cols(); i++)
      {
        hPoly.add(Hyperplane2D(ele.col(i).tail<2>(), ele.col(i).head<2>()));
      }
      polyhedra.push_back(hPoly);
    }

    decomp_ros_msgs::PolyhedronArray poly_msg = DecompROS::polyhedron_array_to_ros(polyhedra);
    poly_msg.header.frame_id = "map";
    poly_msg.header.stamp = ros::Time::now();
    debug_galaxy_poly_pub_.publish(poly_msg);

  }

  void PolyTrajOptimizer::setSurroundTrajs(plan_utils::SurroundTrajData *surround_trajs_ptr) { surround_trajs_ = surround_trajs_ptr; }

  void PolyTrajOptimizer::setDroneId(const int drone_id) { drone_id_ = drone_id; }

} // namespace plan_manage