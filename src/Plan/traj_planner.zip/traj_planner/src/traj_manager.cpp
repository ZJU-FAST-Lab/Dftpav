#include "plan_manage/traj_manager.h"

#include <glog/logging.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <google/protobuf/text_format.h>
#include <omp.h>

namespace plan_manage
{

  ErrorType TrajPlanner::Init(const std::string config_path) {
    ReadConfig(config_path);

    // * Planner config
    printf("\nTrajPlanner Config:\n");
    printf(" -- weight_proximity: %lf\n", cfg_.planner_cfg().weight_proximity());

    LOG(INFO) << "[PolyTrajManager]TrajPlanner Config:";
    LOG(INFO) << "[PolyTrajManager] -- low spd threshold: "
              << cfg_.planner_cfg().low_speed_threshold();
    LOG(INFO) << "[PolyTrajManager] -- weight_proximity: "
              << cfg_.planner_cfg().weight_proximity();

    traj_piece_duration_   = cfg_.opt_cfg().traj_piece_duration();

    ploy_traj_opt_.reset(new PolyTrajOptimizer);
    ploy_traj_opt_->setParam(nh_, cfg_);
    //ploy_traj_opt_->setSurroundTrajs(&traj_container_.surround_traj);
    
    /*  kino a* intial  */
    kino_path_finder_.reset(new path_searching::KinoAstar);
    kino_path_finder_->init(cfg_);



    /*teb local planner hzc*/
    /*
    blp_loader_ = std::make_shared<pluginlib::ClassLoader<nav_core::BaseLocalPlanner>>("nav_core", "nav_core::BaseLocalPlanner");
    buffer  = new tf2_ros::Buffer(ros::Duration(10));
    tf = new tf2_ros::TransformListener(*buffer);
    costmap_ros_ =  new costmap_2d::Costmap2DROS("local_costmap",*buffer);
    costmap_ros_->pause();
    tc_ = blp_loader_->createInstance(std::string("teb_local_planner/TebLocalPlannerROS"));
    tc_->initialize(blp_loader_->getName(std::string("teb_local_planner/TebLocalPlannerROS")),buffer,costmap_ros_);
    costmap_ros_->start();*/



    KinopathPub = nh_.advertise<nav_msgs::Path>("/KinoPathMsg", 1);
    DensePathVisPub = nh_.advertise<geometry_msgs::PoseArray>("/libai/vis_front_end",1);
    DensePathPub = nh_.advertise<nav_msgs::Path>("/libai/front_end",1);

    /*debug*/

    Debugtraj0Pub = nh_.advertise<nav_msgs::Path>("/debug/vis_traj_0", 1);
    Debugtraj1Pub = nh_.advertise<nav_msgs::Path>("/debug/vis_traj_1", 1);
    


    return kSuccess;
  }


  // use kinodynamic a* to generate a path
  ErrorType TrajPlanner::getKinoPath(Eigen::Vector4d &end_state){

    Eigen::Vector4d start_state;
    Eigen::Vector2d init_ctrl;

    start_state << head_state_.vec_position, head_state_.angle, head_state_.velocity;    
    init_ctrl << head_state_.steer, head_state_.acceleration;
    //steer and acc
    // std::cout << "[kino replan]: start_state " << start_state  << std::endl;

    kino_path_finder_->reset();
    int status = kino_path_finder_->search(start_state, init_ctrl, end_state, false);
    ROS_WARN("success~");
    if (status == path_searching::KinoAstar::NO_PATH)
    {
      std::cout << "[kino replan]: kinodynamic search fail!" << std::endl;

      // retry searching with discontinuous initial state
      kino_path_finder_->reset();
      status = kino_path_finder_->search(start_state, init_ctrl, end_state, false);
      if (status == path_searching::KinoAstar::NO_PATH)
      {
        std::cout << "[kino replan]: Can't find path." << std::endl;
        return kWrongStatus;
      }
      else
      {
        std::cout << "[kino replan]: retry search success." << std::endl;
      }
    }
    else
    {
      std::cout << "[kino replan]: kinodynamic search success." << std::endl;
    }

    kino_path_finder_->getKinoNode(kino_trajs_);

    // ROS_WARN("hzc debug kinodynamic search");
    // std::cout << " kino_trajs_.size() :" <<   kino_trajs_.size()  << std::endl;
    // std::cout << " kino_trajs_.at(0).start_state  :" <<  kino_trajs_.at(0).start_state << std::endl;
    // std::cout << " kino_trajs_.at(0).final_state :" <<   kino_trajs_.at(0).final_state << std::endl;
    //ros::shutdown();
    return kSuccess;
  }

  ErrorType TrajPlanner::ReadConfig(const std::string config_path) {
    printf("\n[EudmPlanner] Loading Traj_planner planner config\n");
    using namespace google::protobuf;
    int fd = open(config_path.c_str(), O_RDONLY);
    io::FileInputStream fstream(fd);
    TextFormat::Parse(&fstream, &cfg_);
    if (!cfg_.IsInitialized()) {
      LOG(ERROR) << "failed to parse config from " << config_path;
      assert(false);
    }
    return kSuccess;
  }

  ErrorType TrajPlanner::set_initial_state(const State& state) {
    has_init_state_ = true;
    head_state_ = state;
    return kSuccess;
  }


  Eigen::MatrixXd TrajPlanner::state_to_flat_output(const State& state) {

    Eigen::MatrixXd flatOutput(2, 3);

    double vel = state.velocity, angle = state.angle; // vel < 0 is ok
    double acc = state.acceleration;

    Eigen::Matrix2d init_R;
    init_R << cos(angle),  -sin(angle),
              sin(angle),   cos(angle);

    if (vel == 0){
      vel = 1e-5;
    }

    flatOutput << state.vec_position, init_R*Eigen::Vector2d(vel, 0.0), 
                  init_R*Eigen::Vector2d(acc, state.curvature * std::pow(vel, 2));

    return flatOutput;
  }

  ErrorType TrajPlanner::RunOnceParking(){
    if(!have_parking_target) return kWrongStatus;
    Eigen::Vector4d parking_end = end_pt;
    stamp_ = map_itf_->GetTimeStamp();
    static TicToc Traj_planner_timer;
    Traj_planner_timer.tic();
    static TicToc timer_prepare;
    timer_prepare.tic();
    // get ego vehicle
    if (map_itf_->GetEgoVehicle(&ego_vehicle_) != kSuccess) {
      LOG(ERROR) << "[PolyTrajManager]fail to get ego vehicle info.";
      return kWrongStatus;
    }
    if (!has_init_state_) { head_state_ = ego_vehicle_.state();}
    has_init_state_ = false;
    if (map_itf_->GetObstacleMap(&grid_map_) != kSuccess) {
      LOG(ERROR) << "[PolyTrajManager]fail to get obstacle map.";
      return kWrongStatus;
    }
    // should call before run MINCO
    // point cloud
    // will be used in corridor generation,plc is stored in the vec_obs
    if (UpdateObsGrids() != kSuccess)
    {
      LOG(ERROR) << "[PolyTrajManager]no obs points.\n";
      return kWrongStatus;
    }
    static int tri_flag = 0;
    if(tri_flag) return kWrongStatus;
    if (getKinoPath(parking_end) != kSuccess){
      LOG(ERROR) << "[PolyTrajManager Parking] fail to get the front-end.\n";
      return kWrongStatus;   
    }
    tri_flag =1;
    Eigen::Vector4d start_state;
    start_state << head_state_.vec_position, head_state_.angle, head_state_.velocity; 
    if ((parking_end - start_state).norm() < 1.0){
      ROS_WARN("arrive");
      //have_parking_target_ = false; //hzc
      return kWrongStatus;
    }
    std::cout<<"traj segs num: "<<kino_trajs_.size()<<"\n";
    
    if (RunMINCOParking()!= kSuccess)
    {
      LOG(ERROR) << "[PolyTrajManager Parking] fail to optimize the trajectories.\n";
      return kWrongStatus;
    }
    else{
      ROS_INFO("parking trajectory generate!");
    }

    /*Eigen::Vector4d start_state;
    start_state << head_state_.vec_position, head_state_.angle, head_state_.velocity; 
  
    if ((parking_end - start_state).norm() < 0.3){
      LOG(ERROR) << "[PolyTrajManager Parking] end parking mode.\n";
      //have_parking_target_ = false; //hzc
      return kWrongStatus;
    }*/
    
    /*
    hzc for libai
    publish the posemsg as a vector<Vector3d>
    */
  
    /*geometry_msgs::PoseArray libai_visposemsg;
    nav_msgs::Path libai_pathmsg;
    std::vector<Eigen::Vector4d> statelist = kino_path_finder_->SamplePosList(50);
    // std::vector<Eigen::Vector3d> statelist = kino_path_finder_->getSampleTraj();
    for(auto state:statelist){
      geometry_msgs::PoseStamped pose;
      pose.header.frame_id = "map";
      pose.pose.position.x = state[0];//x
      pose.pose.position.y = state[1];//y
      pose.pose.position.z = 0;
      pose.pose.orientation = tf::createQuaternionMsgFromYaw(state[2]);
      libai_visposemsg.poses.push_back(pose.pose);
      pose.pose.position.z = state[2];//yaw
      pose.header.stamp =  ros::Time().fromSec(state[3]);//time
      libai_pathmsg.poses.push_back(pose);

    }
    libai_visposemsg.header.frame_id = "map";
    libai_pathmsg.header.frame_id = "map";
    DensePathVisPub.publish(libai_visposemsg);
    DensePathPub.publish(libai_pathmsg);
    std::cout<<"final sample pos: "<<libai_visposemsg.poses.back().position.x << " "<<libai_visposemsg.poses.back().position.y<<"\n";
    */
   
   
   return kSuccess;
    /*
      hzc for obca 
      publish the pathmsg
      */
      /*
      nav_msgs::Path pathmsg;
      geometry_msgs::PoseStamped se2pt;
      se2pt.pose.position.x = start_state[0];
      se2pt.pose.position.y = start_state[1];
      se2pt.pose.position.z = start_state[2];  
      pathmsg.poses.push_back(se2pt);      
      
      for(auto traj:kino_trajs_){
        for(int i = 0;i<traj.traj_pts.size();i++ ){
          double theta = traj.thetas[i];
          double px = traj.traj_pts[i][0];
          double py = traj.traj_pts[i][1];
          geometry_msgs::PoseStamped se2pt;
          se2pt.pose.position.x = px;
          se2pt.pose.position.y = py;
          se2pt.pose.position.z = theta;  
          pathmsg.poses.push_back(se2pt);      
        }
      }
      KinopathPub.publish(pathmsg);*/

      /*teb benchmark*/      
      /*
      std::vector<geometry_msgs::PoseStamped> orig_global_plan;
      geometry_msgs::PoseStamped temp_p;
      for( auto traj:kino_trajs_){
        if(traj.traj_pts.size()!=traj.thetas.size()){
          ROS_ERROR("hzc size not merge~");
        }
        for(int i = 0;i<traj.traj_pts.size();i++ ){
          double theta = traj.thetas[i];
          double px = traj.traj_pts[i][0];
          double py = traj.traj_pts[i][1];
          temp_p.pose.position.x = px;
          temp_p.pose.position.y = py;
          temp_p.pose.position.z = 0;
          tf2::Quaternion q1;
          q1.setRPY(0, 0, theta);
          temp_p.pose.orientation.w = q1.w();
          temp_p.pose.orientation.x = q1.x();
          temp_p.pose.orientation.y = q1.y();
          temp_p.pose.orientation.z = q1.z();
          temp_p.header.frame_id = "map";
          temp_p.header.stamp = ros::Time::now();
          orig_global_plan.push_back(temp_p);
        }
      }
      double t_0 = ros::Time::now().toSec();
      tc_->setPlan(orig_global_plan);
      geometry_msgs::Twist vel_cmd;
      if(tc_->computeVelocityCommands(vel_cmd)){
        ROS_WARN("Teb Sucess~");
      }
      double t_1 = ros::Time::now().toSec();
      std::cout<<"t_1-t_0: "<<t_1-t_0<<"\n";
      double velocity = vel_cmd.linear.x;
      double ang_rate = vel_cmd.angular.z;
      double end_px = vel_cmd.angular.x;
      double end_py = vel_cmd.angular.y;
      double dt = vel_cmd.linear.z;
      double end_theta = head_state_.angle+dt*ang_rate;
      Eigen::Vector2d end_vec(end_px,end_py);
      Eigen::Vector2d end_vel(velocity*cos(end_theta),velocity*sin(end_theta));
      Eigen::Vector2d end_acc(0,0);
      //use minco to fit 
      Eigen::MatrixXd flat_finalState(2, 3),  flat_headState(2,3);
      flat_headState  = state_to_flat_output(head_state_);
      flat_finalState<<end_vec,end_vel,end_acc;
      int pieceNum = 2;
      Eigen::MatrixXd ego_innerPs(2, pieceNum-1);
      Eigen::VectorXd ego_piece_dur_vec(pieceNum);
      ego_piece_dur_vec = Eigen::VectorXd::Constant(pieceNum,dt/pieceNum);
      for(int k = 1; k < pieceNum; k++){
        double px;
        double py;
        Eigen::Vector2d head_p = head_state_.vec_position;
        double head_theta = head_state_.angle;
        if(ang_rate!=0){
          px = head_p[0]+velocity/ang_rate*(sin(head_theta+ang_rate*k*dt/pieceNum)-sin(head_theta));
          py = head_p[1]+velocity/ang_rate*(cos(head_theta)-cos(head_theta+ang_rate*k*dt/pieceNum));
        }
        else{
          px = head_p[0]+velocity*cos(head_theta)*k*dt/pieceNum;
          py = head_p[1]+velocity*sin(head_theta)*k*dt/pieceNum;
        }
        ego_innerPs(0, k-1) =  px;
        ego_innerPs(1, k-1) =  py;
      }
      plan_utils::MinJerkOpt initMJO;
      initMJO.reset(flat_headState, flat_finalState, pieceNum);
      initMJO.generate(ego_innerPs, ego_piece_dur_vec);
      traj_container_.clearSingul();
      if(velocity>=0)
        traj_container_.addSingulTraj(initMJO.getTraj(1), head_state_.time_stamp, ego_id_); // todo time 
      else
        traj_container_.addSingulTraj(initMJO.getTraj(-1), head_state_.time_stamp, ego_id_); // todo time
      tebflag = true;

      std::cout<<"------------------------------------------------------------\n";
      std::cout<<"start state: \n"<<flat_headState<<"\n";
      std::cout<<"end state: "<<flat_finalState<<"\n";
      std::cout<<"interval time: \n";
      for(int i = 0;i<pieceNum;i++){
        std::cout<<ego_piece_dur_vec[i]<<" ";
      }
      std::cout<<"\n";
      for(int i = 0; i < pieceNum-1; i++){
        std::cout<<ego_innerPs.col(i).transpose()<<" ";
      }
      std::cout<<"\n";*/
  }

  ErrorType TrajPlanner::RunOnce() 
  {

    stamp_ = map_itf_->GetTimeStamp();
    Eigen::Vector4d parking_end = end_pt;


    static TicToc Traj_planner_timer;
    Traj_planner_timer.tic();

    static TicToc timer_prepare;
    timer_prepare.tic();

    // get ego vehicle
    if (map_itf_->GetEgoVehicle(&ego_vehicle_) != kSuccess) {
      LOG(ERROR) << "[PolyTrajManager]fail to get ego vehicle info.";
      return kWrongStatus;
    }

    if (!has_init_state_) { head_state_ = ego_vehicle_.state();}

    has_init_state_ = false;

    // get obs grid map (may not use it)
    // not use the gridmap!!!!
    if (map_itf_->GetObstacleMap(&grid_map_) != kSuccess) {
      LOG(ERROR) << "[PolyTrajManager]fail to get obstacle map.";
      return kWrongStatus;
    }

    // should call before run MINCO
    // point cloud
    // will be used in corridor generation,plc is stored in the vec_obs
    if (UpdateObsGrids() != kSuccess)
    {
      LOG(ERROR) << "[PolyTrajManager]no obs points.\n";
      return kWrongStatus;
    }

    if(enable_urban_){

      // get ego vehicle reference lane
      if (map_itf_->GetLocalReferenceLane(&nav_lane_local_) != kSuccess) {
        // LOG(ERROR) << "[PolyTrajManager]fail to find ego lane.";
        return kWrongStatus;
      }

      // get ego vehicle behavior
      if (map_itf_->GetEgoDiscretBehavior(&ego_behavior_) != kSuccess) {
        // LOG(ERROR) << "[PolyTrajManager]fail to get ego behavior.";
        return kWrongStatus;
      }//lat_behavior

      // get ego and other forward trajectories
      if (map_itf_->GetForwardTrajectories(&forward_behaviors_, &forward_trajs_,
                                          &surround_forward_trajs_) != kSuccess) {
        // LOG(ERROR) << "[PolyTrajManager]fail to get forward trajectories.";
        return kWrongStatus;
      }//
      // ROS_ERROR("init traj generation");
      if (RunMINCO() != kSuccess)
      {
        // LOG(ERROR) << "[PolyTrajManager]fail to optimize the trajectories.\n";
        return kWrongStatus;
      }
      
      if (UpdateTrajectoryWithCurrentBehavior() != kSuccess) {
        // LOG(ERROR) << "[PolyTrajManager]fail: current behavior "
                  // << static_cast<int>(ego_behavior_) << " not valid.";
        // LOG(ERROR) << "[PolyTrajManager]fail: has "  << valid_behaviors_.size() << " behaviors.";
        return kWrongStatus;
      }
      
    }else{

      return kWrongStatus;

    }


    

    return kSuccess;
  }



  ErrorType TrajPlanner::RunMINCO(){

    // forward_trajs_ = n*11  (n=1,2,3,... the number of behaviors) 3
    int num_behaviors = forward_behaviors_.size();
    valid_behaviors_.clear();
    ref_trajactory_list_.clear();

    Eigen::MatrixXd flat_finalState(2, 3),  flat_headState(2,3);
    flat_headState  = state_to_flat_output(head_state_);
    // p v a for x-y axis

    // for each behavior, do minco optimization
    for (int i = 0; i < num_behaviors; ++i) 
    { 
   
      plan_utils::SurroundTrajData surround_trajs;
      // get surround traj
      ConvertSurroundTraj(&surround_trajs, i);
      //dynamic obs processing
      ploy_traj_opt_->setSurroundTrajs(&surround_trajs);
      

      int piece_nums = forward_trajs_[i].size() - 1;   // 11 - 1 = 10
 
      Eigen::MatrixXd ego_innerPs(2, piece_nums-1);
      Eigen::VectorXd ego_piece_dur_vec(piece_nums);

      plan_utils::MinJerkOpt initMJO;

      for (int k = 1; k < piece_nums; ++k)
      {
        State traj_state = forward_trajs_[i][k].state();
        ego_innerPs(0, k-1) =  traj_state.vec_position[0];
        ego_innerPs(1, k-1) =  traj_state.vec_position[1];
      }

      State final_state_ = forward_trajs_[i][piece_nums].state();

      double total_dur = final_state_.time_stamp - head_state_.time_stamp;
      double ts = total_dur/ (double)piece_nums*1.0;  // 4s 

      flat_finalState = state_to_flat_output(final_state_);
      ego_piece_dur_vec = Eigen::VectorXd::Constant(piece_nums, ts);

      /* generate the init of init trajectory */
      initMJO.reset(flat_headState, flat_finalState, piece_nums);
      initMJO.generate(ego_innerPs, ego_piece_dur_vec);
      plan_utils::Trajectory initTraj = initMJO.getTraj(1); //urban case are always forward moving

      piece_nums =  round(min((head_state_.vec_position - final_state_.vec_position).norm() / 8.0,
                               total_dur / traj_piece_duration_));
      if (piece_nums < 2) piece_nums = 2;

      // store the values
      ego_piece_dur_vec(0) = total_dur;
      // piece_dur
      ego_piece_dur_vec(1) = total_dur / (double)piece_nums;

      
      // get new  ego_innerPs and ego_piece_dur_vec
      if (getGalaxyConst(initTraj, ego_innerPs, ego_piece_dur_vec) != kSuccess){

        
        LOG(ERROR) << "[PolyTrajManager] fail to get constraints.\n";
        return kWrongStatus;

      }
      
      double total_duration = ego_piece_dur_vec.sum();
      
      // for(int i  = 0; i<ego_piece_dur_vec.size(); i++ ){
      //   std::cout<<" "<<ego_piece_dur_vec[i]<<" ";
      // }

      flat_finalState << initTraj.getPos(total_duration), initTraj.getdSigma(total_duration), initTraj.getddSigma(total_duration);

      initMJO.reset(flat_headState, flat_finalState, ego_piece_dur_vec.size());
      initMJO.generate(ego_innerPs, ego_piece_dur_vec);
      initTraj = initMJO.getTraj(1); //urban case are always forward moving
      //obtain the new traj and corridor

      
      /*** STEP 2: OPTIMIZE ***/
      bool flag_success = false;
      // Init planning
      int PN = initTraj.getPieceNum();
      // std::cout << "   PN:     " << PN << std::endl;
      Eigen::MatrixXd all_pos = initTraj.getPositions(); //initstate wp_list finaState
      Eigen::MatrixXd ego_innerPts = all_pos.block(0, 1, 2, PN - 1); //wp_list
      // checkShapeInside(hPoly, BoundPts)
      if(!checkShapeInside(hPolys_.back(), initTraj.getBoundPts(initTraj.getTotalDuration()))){
        ROS_ERROR("end_pt is not in corridor");
      }
      if(!checkShapeInside(hPolys_.front(), initTraj.getBoundPts(0))){
        ROS_ERROR("222222222222222222222222222222222222222");
      }

      
      flag_success = ploy_traj_opt_->OptimizeTrajectory(flat_headState, flat_finalState, 
                                                        ego_innerPts, initTraj.getDurations(), 
                                                        hPolys_, head_state_, 1); //1 means always forward in urban case
      // std::cout << "[PolyTrajManager]The flag_success is: " <<  flag_success << std::endl;
      printLateralBehavior(forward_behaviors_[i]);
      if (flag_success)
      {
        valid_behaviors_.push_back(forward_behaviors_[i]);
        ref_trajactory_list_.push_back(ploy_traj_opt_->getMinJerkOptPtr()->getTraj(1));
        //urban case are always forward moving
      }
      else{
        ROS_ERROR("Minco failed!");
        display_InnterPs_ = all_pos;
        display_hPolys_ = hPolys_;
        return kWrongStatus;
      
      }

      if(forward_behaviors_[i] == ego_behavior_){
        display_InnterPs_ = all_pos;
        display_hPolys_ = hPolys_;
      }
    

    }
    return kSuccess;
  }


  ErrorType TrajPlanner::RunMINCOParking(){

    traj_container_.clearSingul();
    Eigen::MatrixXd flat_finalState(2, 3),  flat_headState(2,3);
    Eigen::VectorXd ego_piece_dur_vec;
    Eigen::MatrixXd ego_innerPs;
    ROS_WARN("begin to run minco");
    flat_headState = kino_trajs_[0].start_state;
    nav_msgs::Path debug_msg0,debug_msg1;
    display_hPolys_.clear();
    double worldtime =  head_state_.time_stamp;
    for (unsigned int i = 0; i < kino_trajs_.size(); ++i){
      ROS_INFO_STREAM("MINCO, kino traj:  "<<i);
      plan_utils::FlatTrajData kino_traj = kino_trajs_.at(i);
      std::vector<Eigen::Vector3d> pts = kino_traj.traj_pts;
      plan_utils::MinJerkOpt initMJO;
      int piece_nums = pts.size();   
      /* generate the init of init trajectory */
      if (piece_nums > 1){
        
        ego_innerPs.resize(2, piece_nums-1);
        ego_piece_dur_vec.resize(piece_nums);

        for (int k = 0; k < piece_nums-1; ++k)
        {
          ego_innerPs(0, k) = pts[k](0);
          ego_innerPs(1, k) = pts[k](1);
          ego_piece_dur_vec(k) = pts[k](2);
        }

        ego_piece_dur_vec(piece_nums-1) = pts[piece_nums-1](2);

      }else{

        piece_nums = 2;

        ego_innerPs.resize(2, 1);
        ego_piece_dur_vec.resize(2);
        
        ego_innerPs(0) = 0.5 * (kino_traj.start_state(0) + kino_traj.final_state(0));
        ego_innerPs(1) = 0.5 * (kino_traj.start_state(1) + kino_traj.final_state(1));
        ego_piece_dur_vec(0) = 0.5 * pts[0](2);
        ego_piece_dur_vec(1) = ego_piece_dur_vec(0);
        
      }

      /* init the trajectory */
      std::cout<<"1111111111kino final state: \n"<<kino_traj.final_state.transpose()<<"\n";
      initMJO.reset(kino_traj.start_state, kino_traj.final_state, piece_nums);
      initMJO.generate(ego_innerPs, ego_piece_dur_vec);
      plan_utils::Trajectory initTraj = initMJO.getTraj(kino_traj.singul);
      double total_dur = initTraj.getTotalDuration();
      //ininTraj vis traj0 for debug
      {
        for(double t  = 0.0; t <= initTraj.getTotalDuration(); t+=0.01){
          geometry_msgs::PoseStamped pose;
          pose.header.frame_id = "map";
          pose.pose.position.x = initTraj.getPos(t)[0];//x
          pose.pose.position.y = initTraj.getPos(t)[1];//y
          pose.pose.position.z = 0.2;
          debug_msg0.poses.push_back(pose);
        }
        debug_msg0.header.frame_id = "map";
      }
      /*
      {
        std::cout<<"init traj0 cur: \n";        
        for(int k1 = 0;k1<initTraj.getPieceNum();k1++){
          for(int k2 = 0; k2 <= 16;k2++){
            double time = initTraj.getDurations()[k1];
            time = time*k2/16.0;
            initTraj[k1].getCurv(time);
          }
        }
        
        std::cout<<"\n";
      }*/




    
      
      piece_nums =  ego_piece_dur_vec.size();
      if (piece_nums < 2) piece_nums = 2;
      ego_piece_dur_vec(0) = total_dur;
      ego_piece_dur_vec(1) = total_dur / (double)piece_nums;

      //get new  ego_innerPs and ego_piece_dur_vec 
      if (getGalaxyConst(initTraj, ego_innerPs, ego_piece_dur_vec) != kSuccess){
        Debugtraj0Pub.publish(debug_msg0);
        Debugtraj1Pub.publish(debug_msg1);
        LOG(ERROR) << "[PolyTrajParkManager] fail to get constraints.\n";
        return kWrongStatus;

      }
      double total_duration = ego_piece_dur_vec.sum();
      flat_finalState << initTraj.getPos(total_duration), initTraj.getdSigma(total_duration), initTraj.getddSigma(total_duration);
      std::cout<<"22222222222flat_finalState: \n"<<flat_finalState.transpose()<<"\n";
      initMJO.reset(kino_traj.start_state, flat_finalState, ego_piece_dur_vec.size());
      initMJO.generate(ego_innerPs, ego_piece_dur_vec);

      std::cout<<"piece num: "<<ego_piece_dur_vec.size()<<"\n";
      for(int i = 0;i<ego_piece_dur_vec.size();i++){
        std::cout<<ego_piece_dur_vec[i]<<" ";
      }
      std::cout<<std::endl;

      initTraj = initMJO.getTraj(kino_traj.singul);
      //ininTraj vis traj1 for debug
      {
        // for(double t  = 0.0; t <= initTraj.getTotalDuration(); t+=0.01){
        //   geometry_msgs::PoseStamped pose;
        //   pose.header.frame_id = "map";
        //   pose.pose.position.x = initTraj.getPos(t)[0];//x
        //   pose.pose.position.y = initTraj.getPos(t)[1];//y
        //   pose.pose.position.z = 0.2;
        //   debug_msg1.poses.push_back(pose);
        // }
        for(int i = 0;i<ego_innerPs.cols();i++){
          geometry_msgs::PoseStamped pose;
          pose.header.frame_id = "map";
          pose.pose.position.x = ego_innerPs(0,i);//x
          pose.pose.position.y = ego_innerPs(1,i);//y
          pose.pose.position.z = 0.2;
          debug_msg1.poses.push_back(pose);
        }
        debug_msg1.header.frame_id = "map";
      }
       Debugtraj0Pub.publish(debug_msg0);
       Debugtraj1Pub.publish(debug_msg1);  



      /*** STEP 2: OPTIMIZE ***/
      bool flag_success = false;
      // Init planning
      int PN = initTraj.getPieceNum();
      Eigen::MatrixXd all_pos = initTraj.getPositions();
      Eigen::MatrixXd ego_innerPts = all_pos.block(0, 1, 2, PN - 1);
      Eigen::MatrixXd TEMP =  initMJO.getInitConstraintPoints(8); //not used
      /*** set the initilizations ***/
      display_InnterPs_ = all_pos;
      display_hPolys_.insert(display_hPolys_.end(),hPolys_.begin(),hPolys_.end());
      display_OptimalPs_ = ego_innerPts;
      ploy_traj_opt_ ->setSurroundTrajs(NULL);
      double totime = initTraj.getTotalDuration();
      // flat_finalState = kino_traj.final_state; //debug hzc
      std::cout<<"333333 flat_final state: \n"<< flat_finalState.transpose()<<"\n";
      std::cout<<"init cost: "<<initMJO.getTrajJerkCost()<<" time: "<<initTraj.getTotalDuration()<<std::endl;
       if(!checkShapeInside(hPolys_.back(), initTraj.getBoundPts(initTraj.getTotalDuration()))){
        ROS_ERROR("11111111111111111111111111111111111111111");
      }
      if(!checkShapeInside(hPolys_.front(), initTraj.getBoundPts(0))){
        ROS_ERROR("222222222222222222222222222222222222222");
      }

      flag_success = ploy_traj_opt_->OptimizeTrajectory(kino_traj.start_state, flat_finalState, 
                                                        ego_innerPts,initTraj.getDurations(), 
                                                        hPolys_, head_state_, kino_traj.singul,0.0);
                                                        //0.05
      std::cout<<"optimized cost: "<<ploy_traj_opt_->getMinJerkOptPtr()->getTrajJerkCost()<<" time: "<<ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getTotalDuration()<<"\n";

      if (flag_success)
      {
        std::cout << "[PolyTrajManager] Planning success ! " << std::endl;
        double tt = ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getTotalDuration();
        Eigen::Vector2d p = ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getPos(tt);
        Eigen::Vector2d v = ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getdSigma(tt);
        traj_container_.addSingulTraj(ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul), worldtime, ego_id_); // todo time
        worldtime = traj_container_.singul_traj.back().end_time;
        std::cout<<"----------------------------------------------\n";
        
       /*
        std::cout<<"init traj cur: \n";
        for(int k1 = 0;k1<initTraj.getPieceNum();k1++){
          for(int k2 = 0; k2 <= 16;k2++){
            double time = initTraj.getDurations()[k1];
            time = time*k2/16.0;
            initTraj[k1].getCurv(time);
          }
        }
        std::cout<<"\n";
        
        std::cout<<"optimized traj cur: \n";
        for(int k1 = 0;k1<ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getPieceNum();k1++){
          for(int k2 = 0; k2 <= 16;k2++){
            double time = ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getDurations()[k1];
            time = time*k2/16.0;
            ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul)[k1].getCurv(time);
          }
        }
        std::cout<<"\n";
        std::cout<<"optimized end p: "<<p.transpose()<<"\n";
        std::cout<<"optimized end v: "<<v.transpose()<<"\n";
        std::cout<<"init_traj end p: "<<initTraj.getPos(totime).transpose()<<"\n";
        std::cout<<"init_traj end v: "<<initTraj.getdSigma(totime).transpose()<<"\n";
        std::cout<<"traj total time: "<<ploy_traj_opt_->getMinJerkOptPtr()->getTraj(kino_traj.singul).getTotalDuration()<<"\n";
        std::cout<<"kino final state: \n"<<kino_traj.final_state<<"\n";*/
      
      }
      else{
        Debugtraj0Pub.publish(debug_msg0);
        Debugtraj1Pub.publish(debug_msg1);
        ROS_ERROR("[PolyTrajManager] Planning fails ! ");
        return kWrongStatus;
      }
    }
    Debugtraj0Pub.publish(debug_msg0);
    Debugtraj1Pub.publish(debug_msg1);

    return kSuccess;
  }


  void TrajPlanner::printLateralBehavior(LateralBehavior lateral_behavior){
    static std::string lateral_behavior_str[5] = {"kUndefined", "kLaneKeeping", "kLaneChangeLeft", "kLaneChangeRight"};
    // std::cout  <<  "\033[34m[LateralBehavior]The behavior is: " << lateral_behavior_str[int(lateral_behavior)] <<  "\033[0m" << std::endl; 
  }

  ErrorType TrajPlanner::UpdateTrajectoryWithCurrentBehavior() {
    int num_valid_behaviors = static_cast<int>(valid_behaviors_.size());
    if (num_valid_behaviors < 1) {
      return kWrongStatus;
    }
    bool find_exact_match_behavior = false;
    int index = 0;
    for (int i = 0; i < num_valid_behaviors; i++) {
      //printLateralBehavior(forward_behaviors_[i]);
      std::cout<< "the ego is "<< std::endl;
      //printLateralBehavior(ego_behavior_);
      if (valid_behaviors_[i] == ego_behavior_) {
        find_exact_match_behavior = true;
        index = i;
      }
    }
    bool find_candidate_behavior = false;
    LateralBehavior candidate_bahavior = common::LateralBehavior::kLaneKeeping;
    if (!find_exact_match_behavior) {
      for (int i = 0; i < num_valid_behaviors; i++) {
        if (valid_behaviors_[i] == candidate_bahavior) {
          find_candidate_behavior = true;
          index = i;
        }
      }
    }
    if (!find_exact_match_behavior && !find_candidate_behavior)
      return kWrongStatus;

    
    traj_container_.clearSingul();
    traj_container_.addSingulTraj(ref_trajactory_list_[index], head_state_.time_stamp, ego_id_); // todo time

    return kSuccess;
  }

  ErrorType TrajPlanner::ConvertSurroundTraj(plan_utils::SurroundTrajData* surround_trajs_ptr, int index){

    // * Surrounding vehicle trajs from MPDM
    Eigen::MatrixXd headState(2, 3);
    Eigen::MatrixXd flat_finalState(2, 3);
    Eigen::MatrixXd innerPs;
    Eigen::VectorXd piece_dur_vec;
    int i = 0;
    surround_trajs_ptr->resize(surround_forward_trajs_[index].size());
    //surrounding traj in one behavior 
    //resize: number of surrounded vehicle
    for (auto it = surround_forward_trajs_[index].begin();
              it != surround_forward_trajs_[index].end(); ++it)
    {
      plan_utils::MinJerkOpt surMJO;
      int piece_nums = (int)it->second.size() -1;
      Eigen::MatrixXd ref_wp_sur(2, piece_nums+1);

      for (unsigned int k = 0; k < it->second.size(); ++k)
      {
        State traj_state = it->second[k].state();  // states
        // vertices
        ref_wp_sur(0,k) =  traj_state.vec_position[0];
        ref_wp_sur(1,k) =  traj_state.vec_position[1];
      }

      State init_surround_state = it->second[0].state();
      State fin_surround_state  = it->second[piece_nums].state();

      double ts = (fin_surround_state.time_stamp - init_surround_state.time_stamp)/piece_nums;  // 4s 

      piece_dur_vec.resize(piece_nums);
      piece_dur_vec = Eigen::VectorXd::Constant(piece_nums, ts);

      headState = state_to_flat_output(init_surround_state);
      flat_finalState = state_to_flat_output(fin_surround_state);

      /* generate the init of init trajectory */
      innerPs.resize(2, piece_nums-1);
      innerPs = ref_wp_sur.block(0, 1, 2, piece_nums-1);
      surMJO.reset(headState, flat_finalState, piece_nums);
      surMJO.generate(innerPs, piece_dur_vec);
      plan_utils::Trajectory sur_traj= surMJO.getTraj(1);
      // for other moving objects, we only account the forward
     
      surround_trajs_ptr->at(i).drone_id = it->first;
      surround_trajs_ptr->at(i).traj = sur_traj;
      surround_trajs_ptr->at(i).duration = sur_traj.getTotalDuration();
      surround_trajs_ptr->at(i).start_pos = sur_traj.getJuncPos(0);
      surround_trajs_ptr->at(i).start_time = init_surround_state.time_stamp;
      surround_trajs_ptr->at(i).end_time = init_surround_state.time_stamp + sur_traj.getTotalDuration();
      surround_trajs_ptr->at(i).init_angle = init_surround_state.angle;

      i += 1;
    }

    return kSuccess;
  }


  ErrorType TrajPlanner::set_map_interface(map_utils::TrajPlannerMapItf *map_itf) {
    if (map_itf == nullptr) return kIllegalInput;
    map_itf_ = map_itf;
    map_valid_ = true;

    kino_path_finder_->intialMap(map_itf);

    return kSuccess;
  }


  ErrorType TrajPlanner::getSikangConst(plan_utils::Trajectory &Traj, 
                                        Eigen::MatrixXd &innerPs,  
                                        Eigen::VectorXd &piece_dur_vec){

    hPolys_.clear();
    polys_.clear();
    Eigen::Vector2d first_point, second_point;

    double total_dur = Traj.getTotalDuration();
    int piece_nums = round(total_dur / traj_piece_duration_);
    if (piece_nums < 3) piece_nums = 3;


    double piece_dur = total_dur / (double)piece_nums;
    Eigen::MatrixXd hPoly;
    double interval_time = piece_dur;

    std::vector<Eigen::Vector2d> temp_inner;
    std::vector<double> temp_dur;
  
    double t = 0;
    while(t < total_dur+1e-6)
    {
      
      first_point = Traj.getPos(t);
      std::vector<Eigen::Vector2d> BoundPts = Traj.getBoundPts(t);
      
      if(t > 0) // t >= piece_dur
      {
        if (checkShapeInside(hPoly, BoundPts))
        {
          interval_time = piece_dur;
        }
        else
        {
          // find the closest point
          for (double k = t; k > t - piece_dur; k -= 0.1)
          {
            first_point = Traj.getPos(k);
            BoundPts = Traj.getBoundPts(k);
            if (checkShapeInside(hPoly, BoundPts))
            {

              interval_time = k-(t-piece_dur);
              break;
            }
          }
        }

        if (interval_time < 1e-3) { // need to regenerate a new polytope
          return kWrongStatus;
        }

        temp_inner.push_back(first_point);
        temp_dur.push_back(interval_time);
      }
      //hPoly?
      t += interval_time;

      second_point = Traj.getPos(t);

      vec_Vec2f seed_path;
      seed_path.push_back(first_point);
      seed_path.push_back(second_point);

      EllipsoidDecomp2D decomp_util;
      decomp_util.set_obs(vec_obs_);
      decomp_util.set_local_bbox(Vec2f(12, 12));
      decomp_util.dilate(seed_path);
      vec_E<Polyhedron2D> seed_poly = decomp_util.get_polyhedrons();
      polys_.push_back(seed_poly[0]);

      vec_E<Hyperplane2D> vs = seed_poly[0].hyperplanes();
      Eigen::MatrixXd hPoly(4, vs.size());
      // // normal in sikang's go outside
      for (unsigned int i = 0; i < vs.size(); i++){


        hPoly.col(i).tail<2>()  = vs[i].p_;
        hPoly.col(i).head<2>()  = vs[i].n_; 
      }
      hPolys_.push_back(hPoly);
    }

    int final_size = temp_inner.size()-1;
    innerPs.resize(2, final_size);
    piece_dur_vec.setZero(final_size+1);

    for(int j = 0 ; j < final_size ; j++ ){

      innerPs.col(j) =  temp_inner.at(j);
      piece_dur_vec(j) = temp_dur.at(j);

    }
    piece_dur_vec(final_size) = temp_dur.at(final_size);

    return kSuccess;
  }

  ErrorType TrajPlanner::getGalaxyConst(plan_utils::Trajectory &Traj, 
                                        Eigen::MatrixXd &innerPs,  
                                        Eigen::VectorXd &piece_dur_vec) 
  {
    /*
    ego_piece_dur_vec(0) = total_dur;
    // piece_dur
    ego_piece_dur_vec(1) = total_dur / (double)piece_nums;
    */
    //init_traj wp_list total_time total_time/piecenum
    hPolys_.clear();
    polys_.clear();
    Eigen::MatrixXd hPoly;

    Eigen::Vector2d first_point;
    double angle;
    // set as 15, 15 for normal urban traffic 
    double d_x = 15.0;
    double d_y = 15.0;
    // get the store values
    double total_dur = piece_dur_vec(0);
    double piece_dur = piece_dur_vec(1);


    // std::cout << " total_dur  " <<  total_dur  << std::endl;
    // std::cout << " piece_dur  " <<  piece_dur  << std::endl;


    double interval_time = piece_dur;

    std::vector<Eigen::Vector2d> temp_inner;
    std::vector<double> temp_dur;
  
    double t = 0;
    int index = 0;
    int piecenum = total_dur/piece_dur;

    /*std::vector<Eigen::Vector2d> wp_list;
    std::vector<double> angle_list;
    int piecenum = total_dur/piece_dur;
    for(int  i = 0;i < piecenum; i++){
      double t  =i * piece_dur;
      first_point = Traj.getPos(t);
      angle = Traj.getAngle(t);
      wp_list.push_back(first_point);
      angle_list.push_back(angle);
    } 
    for(int i = 0; i < piecenum; i++){
      angle = angle_list[i];
      first_point = wp_list[i];
      std::vector<Eigen::Vector2d> add_vec_obs;
      Eigen::Matrix2d R;
      R << cos(angle), -sin(angle),
           sin(angle),  cos(angle);
      Eigen::Vector2d p;
      p = R*Eigen::Vector2d(d_x, d_y); //8 8
      add_vec_obs.push_back(first_point + p);
      p = R*Eigen::Vector2d(d_x, -d_y);
      add_vec_obs.push_back(first_point + p);
      p = R*Eigen::Vector2d(-d_x, d_y);
      add_vec_obs.push_back(first_point + p);
      p = R*Eigen::Vector2d(-d_x, -d_y);
      add_vec_obs.push_back(first_point + p);
      plan_utils::corridorBuilder2d(first_point, 100.0, 15.0, 15.0, vec_obs_, add_vec_obs, hPoly);
      hPolys_.push_back(hPoly);
      //check if next point is in the hpoly
      
      if(i<piecenum-1){
        if(checkPosInside(hPoly,wp_list[i+1])){
          temp_inner.push_back(first_point);
          temp_dur.push_back(interval_time);
        }
        else{
          while(true){
            if (checkPosInside(hPoly, wp_list[i+1]))
            {
              break;
            }
            else
            {
              interval_time = 0.0;
              // find the closest point
              for (double k = total_dur; k > final_time; k -= 0.01)
              {
                first_point = Traj.getPos(k);
                BoundPts = Traj.getBoundPts(k);
                // if (checkShapeInside(hPoly, BoundPts))
                if (checkPosInside(hPoly, first_point))
                {
                  angle = Traj.getAngle(k);
                  interval_time = k-final_time;
                  break;
                }
              }
            }
            if (interval_time < 1e-3) { // need to regenerate a new polytope
              ROS_ERROR("corridor generate failed!");
              return kWrongStatus;
              d_x += 1;
              d_y += 1;
              hPolys_.pop_back();

            }else{
              temp_inner.push_back(first_point);
              temp_dur.push_back(interval_time);
              final_time = final_time+interval_time;
              std::vector<Eigen::Vector2d> add_vec_obs;
              Eigen::Matrix2d R;
              R << cos(angle), -sin(angle),
                  sin(angle),  cos(angle);

              Eigen::Vector2d p;

              p = R*Eigen::Vector2d(d_x, d_y); //8 8
              add_vec_obs.push_back(first_point + p);
              p = R*Eigen::Vector2d(d_x, -d_y);
              add_vec_obs.push_back(first_point + p);
              p = R*Eigen::Vector2d(-d_x, d_y);
              add_vec_obs.push_back(first_point + p);
              p = R*Eigen::Vector2d(-d_x, -d_y);
              add_vec_obs.push_back(first_point + p);
              plan_utils::corridorBuilder2d(first_point, 100.0, 15.0, 15.0, vec_obs_, add_vec_obs, hPoly);
              hPolys_.push_back(hPoly);
            }
          }
        }
      }
      else{
        //i = piecenum-1

      }
    }*/







    while(t <= total_dur - piece_dur)
    {
      first_point = Traj.getPos(t);
      angle = Traj.getAngle(t);
      std::vector<Eigen::Vector2d> BoundPts = Traj.getBoundPts(t);
      //Corner points of the vehicle

      if(t > 0) // t >= piece_dur from the second
      {
        // if (checkShapeInside(hPoly, BoundPts))
        if (checkPosInside(hPoly, first_point))
        {
          interval_time = piece_dur;
        }
        else
        {
          interval_time = 0.0;
          // find the closest point
          for (double k = t; k > t - piece_dur; k -= 0.05)
          {
            first_point = Traj.getPos(k);
            BoundPts = Traj.getBoundPts(k);
            // if (checkShapeInside(hPoly, BoundPts))
            if (checkPosInside(hPoly, first_point))
            {
              angle = Traj.getAngle(k);
              interval_time = k-(t-piece_dur);
              
              break;
            }
          }
        }

        if (interval_time < 1e-3) { // need to regenerate a new polytope
          
          std::cout<< "parking fail to generate the polytope..." << std::endl;
          return kWrongStatus;
          d_x += 1;
          d_y += 1;
          hPolys_.pop_back();

        }else{

          temp_inner.push_back(first_point);
          temp_dur.push_back(interval_time);

        }
        
      }

      t += interval_time;

      std::vector<Eigen::Vector2d> add_vec_obs;


      Eigen::Matrix2d R;
      R << cos(angle), -sin(angle),
           sin(angle),  cos(angle);

      Eigen::Vector2d p;

      p = R*Eigen::Vector2d(d_x, d_y); //8 8
      add_vec_obs.push_back(first_point + p);
      p = R*Eigen::Vector2d(d_x, -d_y);
      add_vec_obs.push_back(first_point + p);
      p = R*Eigen::Vector2d(-d_x, d_y);
      add_vec_obs.push_back(first_point + p);
      p = R*Eigen::Vector2d(-d_x, -d_y);
      add_vec_obs.push_back(first_point + p);
      
      plan_utils::corridorBuilder2d(first_point, 100.0, 15.0, 15.0, vec_obs_, add_vec_obs, hPoly);
      hPolys_.push_back(hPoly);
      index += 1;

    }
    double final_time = t-interval_time;
    //make sure the end point is corvered by the corridor
    while(true){
      first_point = Traj.getPos(total_dur);
      angle = Traj.getAngle(total_dur);
      std::vector<Eigen::Vector2d> BoundPts = Traj.getBoundPts(total_dur);
      //Corner points of the vehicle
      if (checkShapeInside(hPoly, BoundPts))
      {
        // interval_time = piece_dur;
        break;
      }
      else
      {
        interval_time = 0.0;
        // find the closest point
        for (double k = total_dur; k > final_time; k -= 0.01)
        {
          first_point = Traj.getPos(k);
          BoundPts = Traj.getBoundPts(k);
          // if (checkShapeInside(hPoly, BoundPts))
          if (checkPosInside(hPoly, first_point))
          {
            angle = Traj.getAngle(k);
            interval_time = k-final_time;
            break;
          }
        }
      }
      if (interval_time < 1e-3) { // need to regenerate a new polytope
        ROS_ERROR("corridor generate failed!");
        return kWrongStatus;
        d_x += 1;
        d_y += 1;
        hPolys_.pop_back();

      }
      else{
        temp_inner.push_back(first_point);
        temp_dur.push_back(interval_time);
        final_time = final_time+interval_time;
        std::vector<Eigen::Vector2d> add_vec_obs;
        Eigen::Matrix2d R;
        R << cos(angle), -sin(angle),
            sin(angle),  cos(angle);

        Eigen::Vector2d p;

        p = R*Eigen::Vector2d(d_x, d_y); //8 8
        add_vec_obs.push_back(first_point + p);
        p = R*Eigen::Vector2d(d_x, -d_y);
        add_vec_obs.push_back(first_point + p);
        p = R*Eigen::Vector2d(-d_x, d_y);
        add_vec_obs.push_back(first_point + p);
        p = R*Eigen::Vector2d(-d_x, -d_y);
        add_vec_obs.push_back(first_point + p);
        plan_utils::corridorBuilder2d(first_point, 100.0, 15.0, 15.0, vec_obs_, add_vec_obs, hPoly);
        hPolys_.push_back(hPoly);
      }
    }
    double left_time = total_dur-final_time;
    if (left_time < 1e-3){ // reset the final state
      //bug
      int final_size = temp_inner.size()-1;
      innerPs.resize(2, final_size);
      piece_dur_vec.setZero(final_size+1);

      for(int j = 0 ; j < final_size ; j++ ){

        innerPs.col(j) =  temp_inner.at(j);
        piece_dur_vec(j) = temp_dur.at(j);

      }

      piece_dur_vec(final_size) = temp_dur.at(final_size);
      hPolys_.pop_back();
      ROS_ERROR("reset");
 
    }else{

      int final_size = temp_inner.size();
      innerPs.resize(2, final_size);
      piece_dur_vec.setZero(final_size+1);

      for(int j = 0 ; j < final_size ; j++ ){

        innerPs.col(j) =  temp_inner.at(j);
        piece_dur_vec(j) = temp_dur.at(j);

      }

      piece_dur_vec(final_size) = left_time;

    }
    return kSuccess;
  }


  bool TrajPlanner::checkShapeInside(Eigen::MatrixXd &hPoly, 
                                     std::vector<Eigen::Vector2d> vertices) 
  {

    Eigen::Vector2d p_, n_;
    double signed_dist;
    for (int i = 0; i < hPoly.cols(); i++)
    {
      p_ = hPoly.col(i).tail<2>();
      n_ = hPoly.col(i).head<2>();

      for (auto &pt : vertices)
      {
        signed_dist = n_.dot(pt- p_);
        if (signed_dist > 1e-6){ 
          return false;
        }
      }
    }

    return true; // inside

  }
  bool TrajPlanner::checkPosInside(Eigen::MatrixXd &hPoly,Eigen::Vector2d pos){
    Eigen::Vector2d p_, n_;
    double signed_dist;
    for (int i = 0; i < hPoly.cols(); i++)
    {
      p_ = hPoly.col(i).tail<2>();
      n_ = hPoly.col(i).head<2>();
      signed_dist = n_.dot(pos- p_);
      if (signed_dist > 1e-6){ 
        return false;
      }
    }
    return true; // inside
  }

  ErrorType TrajPlanner::UpdateObsGrids(){
    
    map_itf_->GetObstacleGrids(&obs_grids_);
    vec_obs_.resize(obs_grids_.size());

    int i = 0;

    for (const auto obs : obs_grids_)
    {
        vec_obs_[i](0) = obs[0];
        vec_obs_[i](1) = obs[1];
        i += 1;

    }

    return kSuccess;
  }
}  // namespace plan_manage