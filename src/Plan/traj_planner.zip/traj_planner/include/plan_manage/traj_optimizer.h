#ifndef _TRAJ_OPTIMIZER_H_
#define _TRAJ_OPTIMIZER_H_

#include <Eigen/Eigen>
#include <ros/ros.h>

#include <plan_utils/traj_container.hpp>
#include "minco_config.pb.h"

#include "geo_utils2d/lbfgs.hpp"
#include "geo_utils2d/geoutils2d.hpp"
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include "common/state/state.h"
#include "plan_utils/traj_visualizer.h"


namespace plan_manage
{

  using namespace std;


  class PolyTrajOptimizer
  {

  private:
    plan_utils::MinJerkOpt jerkOpt_;
    plan_utils::SurroundTrajData *surround_trajs_{NULL}; // Can not use shared_ptr and no need to free

    int drone_id_;
    int traj_resolution_; // number of distinctive constrain points each piece
    int variable_num_;     // optimization variables
    int piece_num_;        // poly traj piece numbers
    int iter_num_;         // iteration of the solver
    double min_ellip_dist2_; // min trajectory distance in surround

    enum FORCE_STOP_OPTIMIZE_TYPE
    {
      DONT_STOP,
      STOP_FOR_REBOUND,
      STOP_FOR_ERROR
    } force_stop_type_;

    /* optimization parameters */
    double wei_obs_;                         // obstacle weight
    double wei_surround_;                       // surround weight
    double wei_feas_;                        // feasibility weight
    double wei_sqrvar_;                      // squared variance weight
    double wei_time_;                        // time weight
    double surround_clearance_; // safe distance
    double max_vel_, max_acc_, max_cur_;       // dynamic limits
    common::VehicleParam veh_param_;
    double t_now_;
    std::vector<Eigen::Vector2d> lz_set_;

    // Each col of cfgHs denotes a facet (outter_normal^T,point^T)^T
    std::vector<Eigen::MatrixXd> cfgHs;
    Eigen::Matrix<double, 2, 2> B_h;
    common::State head_state_;
    int singul_;
    double epis;

    /*debug*/
    Eigen::MatrixXd ctrl_points_;
    std::vector<Eigen::Vector2d> cos_points;
    std::vector<Eigen::Vector2d> key_points;
    std::vector<Eigen::MatrixXd> debug_hPolys;

  public:
    
    PolyTrajOptimizer() {}
    ~PolyTrajOptimizer() {}

    /* set variables */
    void setParam(ros::NodeHandle nh, planning::minco::Config cfg_);
    ros::Publisher debug_pub,debug_pub1,debug_galaxy_poly_pub_,debug_key_points_pub;
    void displayPoints();
    void displayCosPoints();
    void displayBugPoly();
    void displayKeyPoints();
    // void setEnvironment(const GridMap::Ptr &map);
    void setControlPoints(const Eigen::MatrixXd &points);
    void setSurroundTrajs(plan_utils::SurroundTrajData *surround_trajs_ptr);
    void setDroneId(const int drone_id);

    /* helper functions */
    inline const plan_utils::MinJerkOpt *getMinJerkOptPtr(void) { return &jerkOpt_; }
    inline int get_traj_resolution_() { return traj_resolution_; };
    inline double getsurroundClearance(void) { return surround_clearance_; }

    /* main planning API */
    bool OptimizeTrajectory(const Eigen::MatrixXd &iniState, const Eigen::MatrixXd &finState,
                            Eigen::MatrixXd &initInnerPts, const Eigen::VectorXd &initT,
                            std::vector<Eigen::MatrixXd> &hPolys, common::State &head_state, int singul, double help_eps = 0.05);


    double log_sum_exp(double alpha, Eigen::VectorXd &all_dists, double &exp_sum);


  private:
    /* callbacks by the L-BFGS optimizer */
    static double costFunctionCallback(void *func_data, const double *x, double *grad, const int n);

    static int earlyExitCallback(void *func_data, const double *x, const double *g,
                                 const double fx, const double xnorm, const double gnorm,
                                 const double step, int n, int k, int ls);

    /* mappings between real world time and unconstrained virtual time */
    template <typename EIGENVEC>
    void RealT2VirtualT(const Eigen::VectorXd &RT, EIGENVEC &VT);

    template <typename EIGENVEC>
    void VirtualT2RealT(const EIGENVEC &VT, Eigen::VectorXd &RT);

    template <typename EIGENVEC, typename EIGENVECGD>
    void VirtualTGradCost(const Eigen::VectorXd &RT, const EIGENVEC &VT,
                          const Eigen::VectorXd &gdRT, EIGENVECGD &gdVT,
                          double &costT);

    /* gradient and cost evaluation functions */
    template <typename EIGENVEC>
    void initAndGetSmoothnessGradCost2PT(EIGENVEC &gdT, double &cost);

    template <typename EIGENVEC>
    void addPVAGradCost2CT(EIGENVEC &gdT, Eigen::VectorXd &costs, const int &K);

    bool obstacleGradCostP(const int i_dp,
                           const Eigen::Vector2d &p,
                           Eigen::Vector2d &gradp,
                           double &costp);

    bool surroundGradCostP(const int i_dp,
                        const double t,
                        const Eigen::Vector2d &p,
                        const Eigen::Vector2d &v,
                        Eigen::Vector2d &gradp,
                        double &gradt,
                        double &grad_prev_t,
                        double &costp);

    bool dynamicObsGradCostP(const int i_dp, // index of constraint point
                                         const double t, // current absolute time
                                         const Eigen::Vector2d &sigma, // the rear model 
                                         const Eigen::Vector2d &dsigma,
                                         const Eigen::Vector2d &ddsigma,
                                         Eigen::Matrix2d &ego_R,
                                         Eigen::Matrix2d &help_R,
                                         Eigen::Vector2d &gradp1,
                                         Eigen::Vector2d &gradp2,
                                         double &gradt,
                                         double &grad_prev_t,
                                         double &costp);



    void distanceSqrVarianceWithGradCost2p(const Eigen::MatrixXd &ps,
                                           Eigen::MatrixXd &gdp,
                                           double &var);

    inline bool extractVs(const std::vector<Eigen::MatrixXd> &hPs,
                          std::vector<Eigen::MatrixXd> &vPs) const
    {
        const int M = hPs.size() - 1;

        vPs.clear();
        vPs.reserve(2 * M + 1);

        int nv;
        Eigen::MatrixXd curIH, curIV, curIOB;
        for (int i = 0; i < M; i++)
        {
            if (!geoutils::enumerateVs(hPs[i], curIV))
            {
                return false;
            }
            nv = curIV.cols();
            curIOB.resize(3, nv);
            curIOB << curIV.col(0), curIV.rightCols(nv - 1).colwise() - curIV.col(0);
            vPs.push_back(curIOB);

            curIH.resize(6, hPs[i].cols() + hPs[i + 1].cols());
            curIH << hPs[i], hPs[i + 1];
            if (!geoutils::enumerateVs(curIH, curIV))
            {
                return false;
            }
            nv = curIV.cols();
            curIOB.resize(3, nv);
            curIOB << curIV.col(0), curIV.rightCols(nv - 1).colwise() - curIV.col(0);
            vPs.push_back(curIOB);
        }

        if (!geoutils::enumerateVs(hPs.back(), curIV))
        {
            return false;
        }
        nv = curIV.cols();
        curIOB.resize(3, nv);
        curIOB << curIV.col(0), curIV.rightCols(nv - 1).colwise() - curIV.col(0);
        vPs.push_back(curIOB);

        return true;
    }

    std::vector<Eigen::MatrixXd> debug_P;
    std::vector<Eigen::VectorXd> debug_T;
    std::vector<double> debug_cost;

    void updatePT(const Eigen::MatrixXd &inPs,const Eigen::VectorXd &ts, double cost);
    void getBoundPts(Eigen::Vector2d &position, double angle, std::vector<Eigen::Vector2d> &BoundVertices);
    void positiveSmoothedL1(const double &x, double &f, double &df);

  public:
    typedef unique_ptr<PolyTrajOptimizer> Ptr;

  };

} // namespace plan_manage
#endif